<?php
session_start();
// Session timeout management
$timeout_duration = 900; // 15 minutes
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $timeout_duration) {
    session_unset();
    session_destroy();
    header('Location: index.php?timeout=1');
    exit;
}
$_SESSION['LAST_ACTIVITY'] = time();
require_once 'session_check.php';

if (!isset($_SESSION['user_id']) || !isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}

$mysqli = new mysqli('localhost', 'root', '', 'oschat');
if ($mysqli->connect_errno) {
    die('Database connection failed.');
}

// Get the current user's role
$stmt = $mysqli->prepare('SELECT role FROM users WHERE id = ?');
$stmt->bind_param('i', $_SESSION['user_id']);
$stmt->execute();
$stmt->bind_result($role);
$stmt->fetch();
$stmt->close();

if (!in_array($role, ['Super Administrator', 'Administrator', 'Super Moderator', 'Moderator', 'Female Moderator'])) {
    $mysqli->close();
    header('Location: chat.php'); // Redirect to chat, not index
    exit;
}

// Fetch all users for management
$result = $mysqli->query('SELECT id, username, email, role FROM users ORDER BY id ASC');
$users = [];
while ($row = $result->fetch_assoc()) {
    $users[] = $row;
}

// Fetch currently logged-in users
$loggedInUsersResult = $mysqli->query('SELECT id, username, role FROM users WHERE is_logged_in = 1 ORDER BY username ASC');
$loggedInUsers = [];
while ($row = $loggedInUsersResult->fetch_assoc()) {
    $loggedInUsers[] = $row;
}

// Fetch all roles for dynamic dropdown
$rolesResult = $mysqli->query('SELECT role FROM roles_permissions');
$allRoles = [];
while ($row = $rolesResult->fetch_assoc()) {
    $allRoles[] = $row['role'];
}
// Fetch all rooms
$roomsResult = $mysqli->query('SELECT * FROM rooms ORDER BY name ASC');
$rooms = [];
while ($row = $roomsResult->fetch_assoc()) {
    $rooms[] = $row;
}
$mysqli->close();
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>Admin Panel - oS Legends Chat</title>
    <link href="css.css" rel="stylesheet" type="text/css"/>
    <style>
        body {
            background: #181818;
            color: #fff;
            font-family: 'Segoe UI', Arial, sans-serif;
        }
        .admin-navbar {
            background: #23272e;
            box-shadow: 0 2px 8px #0006;
            padding: 0;
            margin-bottom: 36px;
            border-radius: 0 0 14px 14px;
            position: sticky;
            top: 0;
            z-index: 100;
            max-width: 1200px;
            margin-left: auto;
            margin-right: auto;
        }
        .admin-navbar ul {
            list-style: none;
            margin: 0 auto;
            padding: 0 18px;
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 38px;
            min-height: 62px;
            max-width: 1200px;
        }
        .admin-navbar li {
            display: flex;
            align-items: center;
        }
        .admin-navbar a, .admin-navbar button {
            color: #FFC300;
            background: none;
            border: none;
            font-size: 1.18em;
            font-weight: bold;
            padding: 14px 28px 14px 28px;
            text-decoration: none;
            border-radius: 8px;
            transition: background 0.2s, color 0.2s, box-shadow 0.2s;
            cursor: pointer;
            letter-spacing: 0.5px;
        }
        .admin-navbar a:hover, .admin-navbar button:hover {
            background: #333;
            color: #fff200;
            box-shadow: 0 2px 8px #0008;
        }
        .admin-table {
            width: 95%;
            margin: 24px auto;
            border-collapse: collapse;
            background: #23272e;
            color: #fff;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 8px #0006;
        }
        .admin-table th, .admin-table td {
            border: 1px solid #333;
            padding: 12px 8px;
            text-align: center;
        }
        .admin-table th {
            background: #2c2f36;
            font-size: 1.08em;
            letter-spacing: 1px;
        }
        .admin-header {
            text-align: center;
            margin: 40px 0 18px 0;
            color: #FFC300;
            font-size: 2em;
            letter-spacing: 1px;
        }
        .admin-section {
            background: #22242a;
            border-radius: 12px;
            box-shadow: 0 2px 8px #0004;
            margin: 32px auto 40px auto;
            padding: 32px 24px 24px 24px;
            width: 94%;
        }
        .admin-actions { margin: 20px auto; text-align: center; }
        .admin-actions a { color: #FFFF00; margin: 0 10px; }
        .admin-actions button { background: #FFC300; color: #181818; border: none; border-radius: 6px; padding: 6px 18px; font-weight: bold; cursor: pointer; transition: background 0.2s, color 0.2s; }
        .admin-actions button:hover { background: #fff200; color: #23272e; }
        .user-profile { background: #23272e; border-radius: 10px; box-shadow: 0 2px 8px #0006; }
        input[type="text"], select { background: #181818; color: #fff; border: 1px solid #444; border-radius: 6px; padding: 8px; }
        input[type="text"]:focus, select:focus { outline: 2px solid #FFC300; }
    </style>
</head>
<body>
    <div id="logoLogin"></div>
    <div id="admin-panel-container">
        <nav class="admin-navbar">
            <ul>
                <li><a href="chat.php">Back to Chat</a></li>
                <li><a href="Admin.php">Admin Home</a></li>
                <li><a href="#logged-in">Logged-In Users</a></li>
                <li><a href="#rooms">Rooms</a></li>
                <li><a href="role_management.php">Role Management / Add a Role</a></li>
                <li><a href="#user-search">User Search</a></li>
                <li>
                    <form action="clear_chat.php" method="post" style="display:inline;">
                        <button type="submit" onclick="return confirm('Are you sure you want to clear the chat room?');">Clear Chat Room</button>
                    </form>
                </li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>

        <div class="admin-section" id="rooms">
        <h2 class="admin-header">Room Management</h2>
        <div style="width:90%;margin:0 auto 30px auto;">
            <form action="create_room.php" method="post" style="margin-bottom:18px;display:flex;gap:10px;align-items:center;">
                <input type="text" name="name" placeholder="New room name" required style="padding:8px;font-size:1.1em;">
                <input type="password" name="password" placeholder="Room password (optional)" style="padding:8px;font-size:1.1em;">
                <button type="submit" style="padding:8px 18px;font-size:1.1em;">Add Room</button>
            </form>
            <table class="admin-table">
                <thead>
                    <tr><th>ID</th><th>Name</th><th>Actions</th></tr>
                </thead>
                <tbody>
                    <?php if (empty($rooms)): ?>
                        <tr><td colspan="3">No rooms found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($rooms as $room): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($room['id']); ?></td>
                            <td><?php echo htmlspecialchars($room['name']); ?></td>
                            <td>
                                <form action="delete_room.php" method="post" style="display:inline;" onsubmit="return confirm('Delete this room?');">
                                    <input type="hidden" name="room_id" value="<?php echo $room['id']; ?>">
                                    <button type="submit">Delete</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        </div>
        <div class="admin-section" id="logged-in">
        <h2 class="admin-header">Currently Logged-In Users</h2>
        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Role</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($loggedInUsers)): ?>
                    <tr>
                        <td colspan="3">No users are currently logged in.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($loggedInUsers as $user): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($user['id']); ?></td>
                            <td><?php echo htmlspecialchars($user['username']); ?></td>
                            <td><?php echo htmlspecialchars($user['role']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>

        </div>
        <?php
        // Query current staff (admins, super mods, mods, female mods)
        $mysqli = new mysqli('localhost', 'root', '', 'oschat');
        $staffRoles = [
            'Super Administrator', 'Administrator', 'Super Moderator', 'Moderator', 'Female Moderator'
        ];
        $placeholders = implode(',', array_fill(0, count($staffRoles), '?'));
        $types = str_repeat('s', count($staffRoles));
        $stmt = $mysqli->prepare("SELECT username, role FROM users WHERE role IN ($placeholders) ORDER BY FIELD(role, 'Super Administrator', 'Administrator', 'Super Moderator', 'Moderator', 'Female Moderator'), username ASC");
        $stmt->bind_param($types, ...$staffRoles);
        $stmt->execute();
        $result = $stmt->get_result();
        $staffList = [];
        while ($row = $result->fetch_assoc()) {
            $staffList[] = $row;
        }
        $stmt->close();
        $mysqli->close();
        ?>
        <div class="admin-section" id="role-legend">
            <h2 class="admin-header">Role Legend (Current Staff)</h2>
            <div id="role-legend-avatars" style="width:90%;margin:0 auto 30px auto;display:flex;flex-wrap:wrap;gap:32px;justify-content:center;"></div>
        </div>
        <div class="admin-section" id="user-search">
        <h2 class="admin-header">User Search</h2>
        <div style="text-align: center; margin: 20px;">
            <input type="text" id="user-search-input" placeholder="Search for a user..." style="width: 50%; padding: 10px;" />
        </div>
        <div id="user-profile-container"></div>
        <div id="user-search-debug" style="color:#ff4444;text-align:center;margin-top:10px;"></div>

        <script>
        const allRoles = <?php echo json_encode($allRoles); ?>;
        // Display current staff for Role Legend (avatars grouped by role, from PHP)
        function loadRoleLegend() {
            const staffRoles = [
                {role: 'Super Administrator', badge: 'images/badges/admin.png'}, // Use admin badge or add your own
                {role: 'Administrator', badge: 'images/badges/admin.png'},
                {role: 'Super Moderator', badge: 'images/badges/s_mod.png'},
                {role: 'Moderator', badge: 'images/badges/mod.png'},
                {role: 'Female Moderator', badge: 'images/badges/f_mod.png'}
            ];
            // Staff list from PHP
            const staffList = <?php echo json_encode($staffList); ?>;
            const container = document.getElementById('role-legend-avatars');
            if (!staffList || staffList.length === 0) {
                container.innerHTML = '<p style="width:100%;text-align:center;">No staff found.</p>';
                return;
            }
            let html = '';
            staffRoles.forEach(roleObj => {
                const users = staffList.filter(u => u.role === roleObj.role);
                if (users.length > 0) {
                    html += `<div style='min-width:200px;max-width:260px;background:#23272e;border-radius:10px;padding:16px 10px 10px 10px;box-shadow:0 2px 8px #0006;margin-bottom:18px;'>`;
                    html += `<div style='font-weight:bold;color:#FFC300;font-size:1.1em;text-align:center;margin-bottom:10px;'>${roleObj.role}</div>`;
                    users.forEach(u => {
                        html += `<div style='display:flex;align-items:center;gap:12px;margin-bottom:10px;'>`;
                        html += `<img src='${roleObj.badge}' alt='${roleObj.role}' style='width:29px;height:21px;border-radius:6px;border:2px solid #FFC300;background:#181818;'>`;
                        html += `<span style='color:#fff;font-size:1.08em;'>${u.username}</span>`;
                        html += `</div>`;
                    });
                    html += `</div>`;
                }
            });
            container.innerHTML = html;
        }
        loadRoleLegend();
        document.getElementById('user-search-input').addEventListener('keyup', function(event) {
            const searchTerm = event.target.value;
            const debugDiv = document.getElementById('user-search-debug');
            debugDiv.textContent = '';
            if (searchTerm.length < 2) {
                document.getElementById('user-profile-container').innerHTML = '';
                return;
            }
            fetch('search_user.php?term=' + encodeURIComponent(searchTerm))
                .then(response => response.json())
                .then(data => {
                    const container = document.getElementById('user-profile-container');
                    container.innerHTML = '';
                    if (!data.success) {
                        debugDiv.textContent = data.error || 'Unknown error from backend.';
                    }
                    if (data.success && data.users.length > 0) {
                        data.users.forEach(user => {
                            // Build role options dynamically
                            let roleOptions = allRoles.map(roleOpt => `<option value="${roleOpt}" ${user.role === roleOpt ? 'selected' : ''}>${roleOpt}</option>`).join('');
                            // Build a detailed profile card
                            let userProfile = `<div class="user-profile" style="background: #333; padding: 24px; margin: 24px auto; width: 80%; border: 1px solid #444; border-radius: 12px;">
                                <h2 style='color:#FFC300;'>${user.username}</h2>
                                <div style='display:flex;flex-wrap:wrap;gap:32px;'>
                                    <div style='min-width:220px;'>
                                        <p><strong>User ID:</strong> ${user.id}</p>
                                        <p><strong>Email:</strong> ${user.email}</p>
                                        <p><strong>Role:</strong> <span id='role-${user.id}'>${user.role}</span></p>
                                        <p><strong>IP Address:</strong> ${user.ip_address}</p>
                                    </div>
                                    <div style='flex:1;'>
                                        <div class="admin-actions" style="margin-bottom:18px;">
                                            <form action="update_role.php" method="post" style="display:inline;">
                                                <input type="hidden" name="user_id" value="${user.id}" />
                                                <select name="new_role">${roleOptions}</select>
                                                <button type="submit">Update Role</button>
                                            </form>
                                            <form action="delete_user.php" method="post" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this user?');">
                                                <input type="hidden" name="user_id" value="${user.id}" />
                                                <button type="submit">Delete User</button>
                                            </form>
                                            <button onclick="banUser('${user.username}', ${user.id}, this)" style="margin-left:10px; background:#ff4444; color:#fff; border:none; border-radius:6px; padding:6px 18px; font-weight:bold; cursor:pointer;">Ban User</button>
                                            <button onclick="unbanUser('${user.username}', ${user.id}, this)" style="margin-left:10px; background:#44c767; color:#fff; border:none; border-radius:6px; padding:6px 18px; font-weight:bold; cursor:pointer;">Unban User</button>
                                        </div>
                                        <div class="ban-history">
                                            <h4>Ban History</h4>
                                            <div id="ban-history-${user.id}"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>`;
                            container.innerHTML += userProfile;
                            fetchBanHistory(user.id);
                        });
                    } else if (data.success && data.users.length === 0) {
                        container.innerHTML = '<p style="text-align:center;">No users found.</p>';
                    }
                })
                .catch(err => {
                    debugDiv.textContent = 'Fetch error: ' + err;
                });
        });

        function fetchBanHistory(userId) {
            fetch('get_ban_history.php?user_id=' + userId)
                .then(response => response.json())
                .then(data => {
                    const historyContainer = document.getElementById('ban-history-' + userId);
                    if (data.success && data.history.length > 0) {
                        let historyHtml = '<ul>';
                        data.history.forEach(ban => {
                            historyHtml += `<li>Banned on ${ban.banned_at} by ${ban.banned_by}</li>`;
                        });
                        historyHtml += '</ul>';
                        historyContainer.innerHTML = historyHtml;
                    } else {
                        historyContainer.innerHTML = '<p>No ban history found.</p>';
                    }
                });
        }

        function banUser(username, userId, btn) {
            if (!confirm('Ban user ' + username + '?')) return;
            btn.disabled = true;
            fetch('ban_user.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'username=' + encodeURIComponent(username)
            })
            .then(response => response.json())
            .then(data => {
                btn.disabled = false;
                if (data.success) {
                    alert('User banned successfully.');
                    document.getElementById('role-' + userId).innerText = 'Banned';
                    fetchBanHistory(userId);
                } else {
                    alert('Ban failed: ' + (data.error || 'Unknown error'));
                }
            });
        }

        function unbanUser(username, userId, btn) {
            if (!confirm('Unban user ' + username + '?')) return;
            btn.disabled = true;
            fetch('update_role.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'user_id=' + encodeURIComponent(userId) + '&new_role=basic user'
            })
            .then(response => response.text())
            .then(data => {
                btn.disabled = false;
                alert('User unbanned (role set to basic user).');
                document.getElementById('role-' + userId).innerText = 'basic user';
                fetchBanHistory(userId);
            });
        }
        </script>
        </div>
    </div>
</body>
</html>
