<?php
// clear_chat.php - Deletes all chat messages (for admin use)
$mysqli = new mysqli('localhost', 'root', '', 'oschat');
if ($mysqli->connect_errno) {
    die('Database connection failed.');
}
// Assuming a table named 'messages' for chat messages
$mysqli->query('TRUNCATE TABLE messages');
$mysqli->close();
header('Location: Admin.php?cleared=1');
exit;
