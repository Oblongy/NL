-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 18, 2026 at 10:46 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `oschat`
--

-- --------------------------------------------------------

--
-- Table structure for table `ban_history`
--

CREATE TABLE `ban_history` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `banned_by_user_id` int(11) NOT NULL,
  `banned_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `reason` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ban_history`
--

INSERT INTO `ban_history` (`id`, `user_id`, `banned_by_user_id`, `banned_at`, `reason`) VALUES
(1, 2, 1, '2026-04-14 20:33:57', NULL),
(2, 3, 1, '2026-04-15 00:09:56', NULL),
(3, 3, 1, '2026-04-15 00:11:19', NULL),
(4, 3, 1, '2026-04-15 00:11:28', NULL),
(5, 3, 1, '2026-04-15 00:16:01', NULL),
(6, 3, 1, '2026-04-15 00:20:02', NULL),
(7, 3, 1, '2026-04-15 00:23:52', NULL),
(8, 3, 1, '2026-04-16 21:26:07', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `role` varchar(50) DEFAULT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `room_id` int(11) DEFAULT 1,
  `is_system` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `user_id`, `username`, `role`, `message`, `created_at`, `room_id`, `is_system`) VALUES
(1, 1, '92CivicRacer', 'Administrator', 'fgbg', '2026-04-16 21:07:45', 1, 0),
(2, 1, '92CivicRacer', 'Administrator', 'gfdgfg', '2026-04-16 21:07:52', 1, 0),
(3, 1, '92CivicRacer', 'Administrator', 'gffdg', '2026-04-16 21:07:57', 1, 0),
(4, 1, '92CivicRacer', 'Administrator', 'dfgdfg', '2026-04-16 21:08:00', 1, 0),
(5, 1, '92CivicRacer', 'Administrator', 'fgfdg', '2026-04-16 21:10:15', 1, 0),
(6, 1, '92CivicRacer', 'Administrator', 'gfdgfg', '2026-04-16 21:10:23', 11, 0),
(7, 1, '92CivicRacer', 'Administrator', 'fghfh', '2026-04-16 21:22:33', 1, 0),
(8, 0, 'System', 'System', 'James, has been banned from the chat.', '2026-04-16 21:26:07', 1, 0),
(9, 1, '92CivicRacer', 'Administrator', 'fdfdf', '2026-04-16 21:56:43', 1, 0),
(10, 1, '92CivicRacer', 'Administrator', '/unban james', '2026-04-16 21:57:05', 1, 0),
(11, 3, 'James', 'Member', './', '2026-04-16 22:30:45', 1, 0),
(12, 3, 'James', 'Member', 'gfgfdg', '2026-04-16 22:30:48', 1, 0),
(13, 1, '92CivicRacer', 'Administrator', './', '2026-04-16 22:43:04', 1, 0),
(14, 1, '92CivicRacer', 'Administrator', 'fg', '2026-04-16 22:43:06', 1, 0),
(15, 1, '92CivicRacer', 'Administrator', 'g', '2026-04-16 22:43:07', 1, 0),
(16, 3, 'James', 'Member', 'sfdsfd', '2026-04-16 22:43:10', 1, 0),
(17, 3, 'James', 'Member', 'sdf', '2026-04-16 22:43:11', 1, 0),
(18, 3, 'James', 'Member', 'sdf', '2026-04-16 22:43:12', 1, 0),
(19, 3, 'James', 'Member', 'sdf', '2026-04-16 22:43:12', 1, 0),
(20, 3, 'James', 'Member', 'sdf', '2026-04-16 22:43:12', 1, 0),
(21, 1, '92CivicRacer', 'Administrator', 'fdsfdsf', '2026-04-16 22:48:38', 1, 0),
(22, 1, '92CivicRacer', 'Administrator', 'dsfdsf', '2026-04-16 22:48:46', 1, 0),
(23, 1, '92CivicRacer', 'Administrator', 'sdfd', '2026-04-16 22:48:47', 1, 0),
(24, 1, '92CivicRacer', 'Administrator', 'sdf', '2026-04-16 22:48:47', 1, 0),
(25, 3, 'James', 'Member', 'sdfdsf', '2026-04-16 22:48:51', 1, 0),
(26, 3, 'James', 'Member', 'sdf', '2026-04-16 22:48:52', 1, 0),
(27, 3, 'James', 'Member', 'dsf', '2026-04-16 22:48:52', 1, 0),
(28, 3, 'James', 'Member', 'f', '2026-04-16 22:48:55', 1, 0),
(29, 3, 'James', 'Member', 'dsf', '2026-04-16 22:48:56', 1, 0),
(30, 1, '92CivicRacer', 'Administrator', 'testttt', '2026-04-16 23:03:11', 1, 0),
(31, 1, '92CivicRacer', 'Administrator', ':P', '2026-04-16 23:03:13', 1, 0),
(32, 1, '92CivicRacer', 'Administrator', 'dfdsf', '2026-04-16 23:14:02', 1, 0),
(33, 1, '92CivicRacer', 'Administrator', 'dsfdfsdf', '2026-04-16 23:14:04', 1, 0),
(34, 1, '92CivicRacer', 'Administrator', 'f', '2026-04-16 23:14:04', 1, 0),
(35, 1, '92CivicRacer', 'Administrator', 'f', '2026-04-16 23:14:04', 1, 0),
(36, 1, '92CivicRacer', 'Administrator', 'dsf', '2026-04-16 23:14:05', 1, 0),
(37, 1, '92CivicRacer', 'Administrator', 'ghngfhghf', '2026-04-16 23:15:41', 1, 0),
(38, 1, '92CivicRacer', 'Administrator', 'ggfhfghgfh', '2026-04-16 23:15:43', 1, 0),
(39, 1, '92CivicRacer', 'Administrator', 'gfh', '2026-04-16 23:15:43', 1, 0),
(40, 1, '92CivicRacer', 'Administrator', 'fg', '2026-04-16 23:15:43', 1, 0),
(41, 1, '92CivicRacer', 'Administrator', 'h', '2026-04-16 23:15:43', 1, 0),
(42, 1, '92CivicRacer', 'Super Administrator', 'UH', '2026-04-16 23:16:31', 1, 0),
(43, 1, '92CivicRacer', 'Super Administrator', 'fddsfsdf', '2026-04-16 23:17:02', 1, 0),
(44, 1, '92CivicRacer', 'Administrator', 'fdsf', '2026-04-16 23:21:34', 1, 0),
(45, 3, 'James', 'Super Administrator', 'sfgsd', '2026-04-16 23:24:29', 1, 0),
(46, 3, 'James', 'Super Administrator', 'fg', '2026-04-16 23:24:29', 1, 0),
(47, 3, 'James', 'Super Administrator', 'sdg', '2026-04-16 23:24:30', 1, 0),
(48, 3, 'James', 'Super Administrator', 's', '2026-04-16 23:24:30', 1, 0),
(49, 3, 'James', 'Super Administrator', 'g', '2026-04-16 23:24:30', 1, 0),
(50, 3, 'James', 'Super Administrator', 'fdsfdsf', '2026-04-16 23:25:03', 1, 0),
(51, 3, 'James', 'Super Administrator', 'fdsfdsf', '2026-04-16 23:26:53', 1, 0),
(52, 3, 'James', 'Super Administrator', 'df', '2026-04-16 23:26:54', 1, 0),
(53, 3, 'James', 'Super Administrator', 'dsf', '2026-04-16 23:26:54', 1, 0),
(54, 3, 'James', 'Super Administrator', 'dsf', '2026-04-16 23:26:54', 1, 0),
(55, 3, 'James', 'Super Administrator', 'sd', '2026-04-16 23:26:54', 1, 0),
(56, 3, 'James', 'Super Administrator', 'fgdfsgfg', '2026-04-16 23:27:11', 1, 0),
(57, 3, 'James', 'Super Administrator', 'sdgfsdg', '2026-04-16 23:37:38', 1, 0),
(58, 3, 'James', 'Super Administrator', ':P', '2026-04-16 23:37:42', 1, 0),
(59, 3, 'James', 'Super Administrator', 'fdsfdsf', '2026-04-16 23:50:36', 1, 0),
(60, 1, '92CivicRacer', 'Super Administrator', '....', '2026-04-17 00:33:53', 1, 0),
(61, 1, '92CivicRacer', 'Super Administrator', 'gfdgfdg', '2026-04-17 22:14:23', 1, 0),
(62, 1, '92CivicRacer', 'Super Administrator', '/whos online', '2026-04-17 23:13:52', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `message_reports`
--

CREATE TABLE `message_reports` (
  `id` int(11) NOT NULL,
  `message_id` int(11) NOT NULL,
  `reporter_user_id` int(11) NOT NULL,
  `reported_user_id` int(11) NOT NULL,
  `reason` varchar(512) NOT NULL,
  `message_snapshot` text DEFAULT NULL,
  `status` varchar(24) NOT NULL DEFAULT 'open',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `message_reports`
--

INSERT INTO `message_reports` (`id`, `message_id`, `reporter_user_id`, `reported_user_id`, `reason`, `message_snapshot`, `status`, `created_at`) VALUES
(1, 46, 3, 1, 'i don\'t like it.', '92CivicRacer: mhmm', 'resolved', '2026-04-15 00:25:57'),
(2, 49, 1, 3, 'testing?', 'James: ?', 'open', '2026-04-15 00:26:41');

-- --------------------------------------------------------

--
-- Table structure for table `mod_audit_log`
--

CREATE TABLE `mod_audit_log` (
  `id` int(11) NOT NULL,
  `actor_user_id` int(11) NOT NULL,
  `action` varchar(64) NOT NULL,
  `target_user_id` int(11) DEFAULT NULL,
  `message_id` int(11) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mod_audit_log`
--

INSERT INTO `mod_audit_log` (`id`, `actor_user_id`, `action`, `target_user_id`, `message_id`, `details`, `ip_address`, `created_at`) VALUES
(1, 1, 'ban', 3, 0, '{\"ban\":\"temporary\",\"seconds\":3600,\"reason\":\"test\"}', '::1', '2026-04-15 00:09:56'),
(2, 1, 'ban', 3, 0, '{\"ban\":\"temporary\",\"seconds\":3600,\"reason\":\"test the ban here.\"}', '::1', '2026-04-15 00:11:19'),
(3, 1, 'ban', 3, 0, '{\"ban\":\"permanent\",\"seconds\":null}', '::1', '2026-04-15 00:11:28'),
(4, 1, 'role_change', 3, 0, '{\"from\":\"Banned\",\"to\":\"basic user\"}', '::1', '2026-04-15 00:13:13'),
(5, 1, 'ban', 3, 0, '{\"ban\":\"temporary\",\"seconds\":3600,\"reason\":\"test\"}', '::1', '2026-04-15 00:16:01'),
(6, 1, 'ban', 3, 0, '{\"ban\":\"temporary\",\"seconds\":86400,\"reason\":\"TEST\"}', '::1', '2026-04-15 00:20:02'),
(7, 1, 'role_change', 3, 0, '{\"from\":\"Banned\",\"to\":\"Super Moderator\"}', '::1', '2026-04-15 00:22:12'),
(8, 1, 'ban', 3, 0, '{\"ban\":\"temporary\",\"seconds\":604800,\"reason\":\"test\"}', '127.0.0.1', '2026-04-15 00:23:52'),
(9, 1, 'role_change', 3, 0, '{\"from\":\"Banned\",\"to\":\"Administrator\"}', '127.0.0.1', '2026-04-15 00:25:27'),
(10, 3, 'report_message', 1, 46, '', '::1', '2026-04-15 00:25:57'),
(11, 1, 'resolve_report', 0, 0, '{\"report_id\":1}', '127.0.0.1', '2026-04-15 00:26:12'),
(12, 1, 'report_message', 3, 49, '', '127.0.0.1', '2026-04-15 00:26:41'),
(13, 1, 'clear_chat', 0, 0, '', '127.0.0.1', '2026-04-15 00:27:04'),
(14, 1, 'role_change', 2, 0, '{\"from\":\"Banned\",\"to\":\"Female Moderator\"}', '127.0.0.1', '2026-04-15 00:28:36'),
(15, 3, 'role_change', 2, 0, '{\"from\":\"Female Moderator\",\"to\":\"Member\"}', '::1', '2026-04-15 00:30:09'),
(16, 1, 'role_change', 3, 0, '{\"from\":\"Administrator\",\"to\":\"basic user\"}', '::1', '2026-04-15 19:59:56'),
(17, 1, 'role_change', 3, 0, '{\"from\":\"basic user\",\"to\":\"Administrator\"}', '127.0.0.1', '2026-04-15 20:38:45'),
(18, 1, 'role_change', 3, 0, '{\"from\":\"Administrator\",\"to\":\"Member\"}', '127.0.0.1', '2026-04-15 20:56:01'),
(19, 1, 'role_change', 3, 0, '{\"from\":\"Member\",\"to\":\"test dummy\"}', '::1', '2026-04-15 22:16:07'),
(20, 1, 'role_change', 3, 0, '{\"from\":\"test dummy\",\"to\":\"basic user\"}', '::1', '2026-04-15 22:21:15'),
(21, 1, 'clear_chat', 0, 0, '', '127.0.0.1', '2026-04-15 23:11:54'),
(22, 1, 'clear_chat', 0, 0, '', '127.0.0.1', '2026-04-16 00:10:07');

-- --------------------------------------------------------

--
-- Table structure for table `mutes`
--

CREATE TABLE `mutes` (
  `user_id` int(11) NOT NULL,
  `muted_until` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mutes`
--

INSERT INTO `mutes` (`user_id`, `muted_until`) VALUES
(1, '2026-04-14 20:24:13'),
(2, '2026-04-14 03:44:55');

-- --------------------------------------------------------

--
-- Table structure for table `private_messages`
--

CREATE TABLE `private_messages` (
  `id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `recipient_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `sent_at` datetime DEFAULT current_timestamp(),
  `is_read` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `private_messages`
--

INSERT INTO `private_messages` (`id`, `sender_id`, `recipient_id`, `message`, `sent_at`, `is_read`) VALUES
(54, 1, 3, 'fgdsgfg', '2026-04-16 20:05:09', 0),
(55, 1, 3, 'hello.', '2026-04-16 20:06:04', 0),
(56, 1, 3, 'gfdgfdg', '2026-04-16 20:06:31', 0),
(57, 1, 3, 'dfdsf', '2026-04-16 20:06:38', 0),
(58, 3, 1, 'fdsfdsf', '2026-04-16 20:07:07', 0),
(59, 3, 1, 'gdgfdg', '2026-04-16 20:09:39', 0),
(60, 3, 1, 'sdfg', '2026-04-16 20:09:40', 0),
(61, 3, 1, 'dsg', '2026-04-16 20:09:40', 0),
(62, 1, 3, 'fvdsf', '2026-04-16 20:09:56', 0),
(63, 1, 3, 'fds', '2026-04-16 20:09:56', 0),
(64, 1, 3, 'dsf', '2026-04-16 20:09:56', 0),
(65, 1, 3, 'd', '2026-04-16 20:09:56', 0),
(66, 1, 3, 'd', '2026-04-16 20:09:57', 0),
(67, 1, 3, 'f', '2026-04-16 20:09:57', 0),
(68, 3, 1, 'dfdsf', '2026-04-16 20:10:12', 0),
(69, 3, 1, 'fgfdg', '2026-04-16 20:11:44', 0),
(70, 3, 1, 'sgsdfg', '2026-04-16 20:12:28', 0),
(71, 3, 1, 'gfg', '2026-04-16 20:13:39', 0),
(72, 1, 3, 'hbgfhgfh', '2026-04-16 20:14:21', 0),
(73, 1, 3, 'GAY', '2026-04-16 20:15:03', 0),
(74, 1, 3, 'gf', '2026-04-16 20:22:23', 0),
(75, 1, 3, 'Oblong likes big black cocks.', '2026-04-16 20:22:33', 0),
(76, 1, 3, 'gfdgf', '2026-04-16 20:24:54', 0),
(77, 1, 3, 'fdsf', '2026-04-16 20:27:43', 0),
(78, 1, 3, 'gfg', '2026-04-16 20:28:08', 0);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `color_hex` char(7) DEFAULT '#CCCCCC',
  `permissions` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `color_hex`, `permissions`) VALUES
(1, 'test dummy', '#b4d3eb', '[]'),
(2, 'Administrator', '#ff3333', '{\"ban_user\":true,\"mute_user\":true,\"kick_user\":true,\"delete_user\":true,\"edit_rooms\":true,\"view_ip\":true,\"edit_keyword_filter\":true,\"view_audit_log\":true,\"manage_roles\":true,\"view_notes\":true,\"edit_notes\":true}'),
(3, 'Super Moderator', '#0492fb', '{\"ban_user\":true,\"mute_user\":true,\"kick_user\":true,\"delete_user\":true,\"edit_rooms\":true,\"view_ip\":true,\"edit_keyword_filter\":true,\"view_audit_log\":true,\"manage_roles\":true,\"view_notes\":true,\"edit_notes\":true}'),
(4, 'Moderator', '#33AAFF', '{\"ban_user\":true,\"mute_user\":true,\"kick_user\":true,\"delete_user\":false,\"edit_rooms\":false,\"view_ip\":true,\"edit_keyword_filter\":false,\"view_audit_log\":true,\"manage_roles\":false,\"view_notes\":true,\"edit_notes\":true}'),
(5, 'Female Moderator', '#FF66CC', '{\"ban_user\":true,\"mute_user\":true,\"kick_user\":true,\"delete_user\":false,\"edit_rooms\":false,\"view_ip\":true,\"edit_keyword_filter\":false,\"view_audit_log\":true,\"manage_roles\":false,\"view_notes\":true,\"edit_notes\":true}'),
(6, 'Member', '#00b700', '[]'),
(7, 'basic user', '#CCCCCC', '{\"ban_user\":false,\"mute_user\":false,\"kick_user\":false,\"delete_user\":false,\"edit_rooms\":false,\"view_ip\":false,\"edit_keyword_filter\":false,\"view_audit_log\":false,\"manage_roles\":false,\"view_notes\":false,\"edit_notes\":false}'),
(8, 'Banned', '#222222', '{\"ban_user\":false,\"mute_user\":false,\"kick_user\":false,\"delete_user\":false,\"edit_rooms\":false,\"view_ip\":false,\"edit_keyword_filter\":false,\"view_audit_log\":false,\"manage_roles\":false,\"view_notes\":false,\"edit_notes\":false}');

-- --------------------------------------------------------

--
-- Table structure for table `roles_permissions`
--

CREATE TABLE `roles_permissions` (
  `role` varchar(32) NOT NULL,
  `can_ban_users` tinyint(1) DEFAULT 0,
  `can_delete_rooms` tinyint(1) DEFAULT 0,
  `can_create_rooms` tinyint(1) DEFAULT 0,
  `can_mute_users` tinyint(1) DEFAULT 0,
  `can_change_roles` tinyint(1) DEFAULT 0,
  `username_color` varchar(8) DEFAULT '#FFC300',
  `text_color` varchar(8) DEFAULT '#FFFFFF',
  `avatar` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles_permissions`
--

INSERT INTO `roles_permissions` (`role`, `can_ban_users`, `can_delete_rooms`, `can_create_rooms`, `can_mute_users`, `can_change_roles`, `username_color`, `text_color`, `avatar`) VALUES
('Administrator', 1, 1, 1, 1, 1, '#ffc300', '#ffc600', 'images/badges/admin.png'),
('Banned', 0, 0, 0, 0, 0, '#000000', '#000000', 'images/badges/banned.png'),
('basic user', 0, 0, 0, 0, 0, '#ffffff', '#ffffff', 'images/badges/basic_user.png'),
('Female Moderator', 1, 0, 0, 1, 0, '#ff80c0', '#ff80c0', 'images/badges/mod.png'),
('Member', 0, 0, 0, 0, 0, '#0ab900', '#00b700', 'images/badges/member.png'),
('Moderator', 1, 0, 0, 1, 0, '#009fff', '#0080ff', 'images/badges/mod.png'),
('Super Administrator', 1, 1, 1, 1, 1, '#00c100', '#ffc600', 'images/badges/Super_admin.png'),
('Super Moderator', 1, 1, 1, 1, 1, '#039efc', '#0080ff', 'images/badges/mod.png');

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `id` int(11) NOT NULL,
  `name` varchar(64) NOT NULL,
  `is_private` tinyint(1) NOT NULL DEFAULT 0,
  `password_hash` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`id`, `name`, `is_private`, `password_hash`, `password`) VALUES
(1, 'Racer Lounge', 0, NULL, NULL),
(2, 'Members Only', 0, NULL, '$2y$10$d5VL4JsFbJ5Jcir9ceW1GOwO8aRi4SeCX6AD.OyBOsZH/bjSKy0fi'),
(13, 'Moderator Room', 0, NULL, '$2y$10$ew1Bt/0eXDXldUlOX4LVT.cO5hR3ivez.rhMBbnUOy3Mj9i0sJRoy');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` varchar(32) NOT NULL DEFAULT 'basic user',
  `ip_address` varchar(45) DEFAULT NULL,
  `is_logged_in` tinyint(1) NOT NULL DEFAULT 0,
  `session_id` varchar(255) DEFAULT NULL,
  `last_activity` timestamp NULL DEFAULT NULL,
  `ban_expires_at` datetime DEFAULT NULL,
  `previous_role` varchar(64) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `role_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `role`, `ip_address`, `is_logged_in`, `session_id`, `last_activity`, `ban_expires_at`, `previous_role`, `created_at`, `role_id`) VALUES
(1, '92CivicRacer', '$2y$10$/bNNZ04pCopgwQrIL8O5OeLusGGub6IHRqiqTQ98OkYp99IBc4Bfu', '92hondaciviccx@gmail.com', 'Super Administrator', '127.0.0.1', 1, 'v0mmpdsor4k0o7c5lk781v0ut7', '2026-04-17 23:25:02', NULL, NULL, '2026-04-15 00:05:02', NULL),
(2, '92CivicSi2NR', '$2y$10$02/bvvojgPZrSDT1DMcRY./PpXmSmNGBJJcCOIWlynEI7QF/dal/C', '92civicsi2nr@gmail.com', 'Super Administrator', '127.0.0.1', 1, '9mj5imdglugkdlrihnllbafbbf', '2026-04-15 00:30:54', NULL, NULL, '2026-04-15 00:05:02', NULL),
(3, 'James', '$2y$10$uw547GoWIgTsGCLCq3BypORvNDjxTZc2QhAc0thMuLZpONl71ipZe', 'james1320@gmail.com', 'Super Administrator', '::1', 1, 'gr41bqtip7ina5iphh5suhf889', '2026-04-17 00:44:06', '2026-04-21 20:23:52', 'Super Moderator', '2026-04-15 00:05:02', 7);

-- --------------------------------------------------------

--
-- Table structure for table `user_notes`
--

CREATE TABLE `user_notes` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  `note` text NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ban_history`
--
ALTER TABLE `ban_history`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `message_reports`
--
ALTER TABLE `message_reports`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_message_reporter` (`message_id`,`reporter_user_id`),
  ADD KEY `idx_status` (`status`,`created_at`);

--
-- Indexes for table `mod_audit_log`
--
ALTER TABLE `mod_audit_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_created` (`created_at`),
  ADD KEY `idx_actor` (`actor_user_id`);

--
-- Indexes for table `mutes`
--
ALTER TABLE `mutes`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `private_messages`
--
ALTER TABLE `private_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `roles_permissions`
--
ALTER TABLE `roles_permissions`
  ADD PRIMARY KEY (`role`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_notes`
--
ALTER TABLE `user_notes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `author_id` (`author_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ban_history`
--
ALTER TABLE `ban_history`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `message_reports`
--
ALTER TABLE `message_reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `mod_audit_log`
--
ALTER TABLE `mod_audit_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `private_messages`
--
ALTER TABLE `private_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_notes`
--
ALTER TABLE `user_notes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `user_notes`
--
ALTER TABLE `user_notes`
  ADD CONSTRAINT `user_notes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `user_notes_ibfk_2` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
