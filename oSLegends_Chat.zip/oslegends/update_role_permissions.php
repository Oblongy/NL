<?php
session_start();
require_once 'session_check.php';
if (!isset($_SESSION['user_id']) || !isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['permissions'])) {
    $mysqli = new mysqli('localhost', 'root', '', 'oschat');
    if ($mysqli->connect_errno) {
        die('Database connection failed.');
    }
    foreach ($_POST['permissions'] as $role => $perms) {
        $can_ban_users = isset($perms['can_ban_users']) ? 1 : 0;
        $can_delete_rooms = isset($perms['can_delete_rooms']) ? 1 : 0;
        $can_create_rooms = isset($perms['can_create_rooms']) ? 1 : 0;
        $can_mute_users = isset($perms['can_mute_users']) ? 1 : 0;
        $can_change_roles = isset($perms['can_change_roles']) ? 1 : 0;
        $username_color = isset($perms['username_color']) ? $perms['username_color'] : '#FFC300';
        $text_color = isset($perms['text_color']) ? $perms['text_color'] : '#FFFFFF';
        $avatar = isset($perms['avatar']) ? $perms['avatar'] : null;
        $stmt = $mysqli->prepare('UPDATE roles_permissions SET can_ban_users=?, can_delete_rooms=?, can_create_rooms=?, can_mute_users=?, can_change_roles=?, username_color=?, text_color=?, avatar=? WHERE role=?');
        $stmt->bind_param('iiiiissss', $can_ban_users, $can_delete_rooms, $can_create_rooms, $can_mute_users, $can_change_roles, $username_color, $text_color, $avatar, $role);
        $stmt->execute();
        $stmt->close();
    }
    $mysqli->close();
    header('Location: role_management.php?success=1');
    exit;
} else {
    header('Location: role_management.php?error=1');
    exit;
}
