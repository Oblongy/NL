<?php
// get_messages.php - Fetch all chat messages from the database
session_start();
header('Content-Type: application/json');
$mysqli = new mysqli('localhost', 'root', '', 'oschat');
if ($mysqli->connect_errno) {
    echo json_encode(['success' => false, 'error' => 'Database error']);
    exit;
}

// Validate room_id
if (!isset($_POST['room_id']) || !is_numeric($_POST['room_id'])) {
    echo json_encode(['success' => false, 'error' => 'Room ID required.']);
    exit;
}
$room_id = intval($_POST['room_id']);

// Check if room exists and if password is required
$stmt = $mysqli->prepare('SELECT password FROM rooms WHERE id = ?');
$stmt->bind_param('i', $room_id);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows === 0) {
    echo json_encode(['success' => false, 'error' => 'Room not found.']);
    $stmt->close();
    $mysqli->close();
    exit;
}
$stmt->bind_result($room_password_hash);
$stmt->fetch();
$stmt->close();

if (!empty($room_password_hash)) {
    $provided_password = isset($_POST['password']) ? $_POST['password'] : '';
    if (!password_verify($provided_password, $room_password_hash)) {
        $mysqli->close();
        echo json_encode(['success' => false, 'error' => 'Incorrect room password.']);
        exit;
    }
}

$stmt = $mysqli->prepare('SELECT username, role, message, created_at FROM messages WHERE room_id = ? ORDER BY id ASC');
$stmt->bind_param('i', $room_id);
$stmt->execute();
$result = $stmt->get_result();
$messages = [];
while ($row = $result->fetch_assoc()) {
    $messages[] = $row;
}
$stmt->close();
$mysqli->close();
echo json_encode(['success' => true, 'messages' => $messages]);
