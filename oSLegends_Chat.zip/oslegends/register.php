<?php
$success = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'], $_POST['email'], $_POST['password'], $_POST['confirm_password'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    if ($password !== $confirm_password) {
        $error = 'Passwords do not match.';
    } elseif (strlen($username) < 3 || strlen($password) < 6) {
        $error = 'Username must be at least 3 characters and password at least 6 characters.';
    } else {
        $mysqli = new mysqli('localhost', 'root', '', 'oschat');
        if ($mysqli->connect_errno) {
            $error = 'Database connection failed.';
        } else {
            // Check if username or email already exists
            $stmt = $mysqli->prepare('SELECT id FROM users WHERE username = ? OR email = ?');
            $stmt->bind_param('ss', $username, $email);
            $stmt->execute();
            $stmt->store_result();
            if ($stmt->num_rows > 0) {
                $error = 'Username or email already exists.';
            } else {
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $stmt->close();
                $role = 'basic user';
                $ip_address = $_SERVER['REMOTE_ADDR'];
                $stmt = $mysqli->prepare('INSERT INTO users (username, password, email, role, ip_address) VALUES (?, ?, ?, ?, ?)');
                $stmt->bind_param('sssss', $username, $hash, $email, $role, $ip_address);
                if ($stmt->execute()) {
                    $success = 'Registration successful! You can now <a href="index.php">login</a>.';
                } else {
                    $error = 'Registration failed. Please try again.';
                }
            }
            $stmt->close();
            $mysqli->close();
        }
    }
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>oS Legends Chat - Register</title>
    <link href="css.css" rel="stylesheet" type="text/css"/>
</head>
<body>
    <div id="logoLogin"></div>
    <div id="containerReg">
        <div id="mainLogin">
            <div id="welcome">
                <p>Create Your oS Legends Account</p>
            </div>
            <?php if ($error): ?>
                <div style="color:red; text-align:center; margin-bottom:10px;">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php elseif ($success): ?>
                <div style="color:green; text-align:center; margin-bottom:10px;">
                    <?php echo $success; ?>
                </div>
            <?php endif; ?>
            <form id="register" action="register.php" method="post" accept-charset="UTF-8">
                <fieldset style="text-align:center;">
                    <legend>Register</legend>
                    <label for="username">UserName:</label><br>
                    <input type="text" name="username" id="username" maxlength="50" required/><br>
                    <label for="email">Email:</label><br>
                    <input type="email" name="email" id="email" maxlength="100" required/><br>
                    <label for="password">Password:</label><br>
                    <input type="password" name="password" id="password" maxlength="50" required/><br>
                    <label for="confirm_password">Confirm Password:</label><br>
                    <input type="password" name="confirm_password" id="confirm_password" maxlength="50" required/><br>
                    <input type="submit" name="Submit" value="Register"/>
                </fieldset>
            </form>
            <div id="loginLink">
                <p style="text-align:center;"><a href="index.php" style="link {color:#FFFF00;}">Back to Login</a></p>
            </div>
        </div>
    </div>
</body>
</html>
