<?php
session_start();
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'], $_POST['password'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $mysqli = new mysqli('localhost', 'root', '', 'oschat');
    if ($mysqli->connect_errno) {
        $error = 'Database connection failed.';
    } else {
        $stmt = $mysqli->prepare('SELECT id, username, password, role FROM users WHERE username = ?');
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows === 1) {
            $stmt->bind_result($id, $user, $hash, $role);
            $stmt->fetch();
            if (password_verify($password, $hash)) {
                if ($role === 'Banned') {
                    $error = 'Your account has been banned.';
                } else {
                    session_regenerate_id(true);
                    $new_session_id = session_id();

                    $_SESSION['user_id'] = $id;
                    $_SESSION['username'] = $user;
                    $_SESSION['role'] = $role;
                    $_SESSION['session_id'] = $new_session_id;

                    $ip_address = $_SERVER['REMOTE_ADDR'];
                    $stmt_update = $mysqli->prepare('UPDATE users SET ip_address = ?, is_logged_in = 1, session_id = ? WHERE id = ?');
                    $stmt_update->bind_param('ssi', $ip_address, $new_session_id, $id);
                    $stmt_update->execute();
                    $stmt_update->close();

                    header('Location: chat.php');
                    exit;
                }
            } else {
                $error = 'Invalid username or password.';
            }
        } else {
            $error = 'Invalid username or password.';
        }
        $stmt->close();
        $mysqli->close();
    }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>oS Legends Chat - Login</title>
<link href="css.css" rel="stylesheet" type="text/css"/>
</head>
<body>
<div id="logoLogin"></div>
<div id="containerLogin">
   <div id="mainLogin">
    <div id="welcome">
      <p>Welcome to oS Legends Chat</p>
      <div id="user-counter"></div>
    </div>
    <?php if ($error): ?>
      <div class="error-message">
        <?php echo htmlspecialchars($error); ?>
      </div>
    <?php endif; ?>
        <form id="login" action="index.php" method="post" accept-charset="UTF-8">
            <fieldset>
            <legend>Login</legend>
            <input type="hidden" name="action" id="submitted" value="login"/>
            <label for="username">UserName:</label><br>
            <input type="text" name="username" id="username2" maxlength="50" required/><br>
            <label for="password">Password:</label><br>
            <input type="password" name="password" id="password" maxlength="50" required/><br>
            <input type="submit" name="Submit" value="Submit"/>
            </fieldset>
            </form>
        <div id="forgotPw">
          <p><a href="forgotpw.php">Forgot Password?</a>        </p>
        </div>
        <div id="newReg">
          <p><a href="register.php">Create Account</a>        </p>
        </div>
    </div>
</div>
<script>
    function fetchUserCount() {
        fetch('get_user_count.php')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('user-counter').innerText = `Users Online: ${data.count}`;
                }
            });
    }

    fetchUserCount();
    setInterval(fetchUserCount, 10000); // Update every 10 seconds
</script>
</body>
</html>