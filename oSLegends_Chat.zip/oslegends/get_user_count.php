<?php
header('Content-Type: application/json');
$mysqli = new mysqli('localhost', 'root', '', 'oschat');
if ($mysqli->connect_errno) {
    echo json_encode(['success' => false, 'error' => 'Database error.']);
    exit;
}

$result = $mysqli->query("SELECT COUNT(*) as count FROM users WHERE role != 'Banned'");
$row = $result->fetch_assoc();
$count = $row['count'];
$mysqli->close();

echo json_encode(['success' => true, 'count' => $count]);
