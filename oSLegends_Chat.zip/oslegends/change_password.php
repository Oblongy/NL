<?php
// change_password.php - Change user password
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}
$success = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['current_password'], $_POST['new_password'], $_POST['confirm_password'])) {
    $mysqli = new mysqli('localhost', 'root', '', 'oschat');
    if ($mysqli->connect_errno) {
        $error = 'Database connection failed.';
    } else {
        $stmt = $mysqli->prepare('SELECT password FROM users WHERE id = ?');
        $stmt->bind_param('i', $_SESSION['user_id']);
        $stmt->execute();
        $stmt->bind_result($hash);
        $stmt->fetch();
        $stmt->close();
        if (!password_verify($_POST['current_password'], $hash)) {
            $error = 'Current password is incorrect.';
        } elseif ($_POST['new_password'] !== $_POST['confirm_password']) {
            $error = 'New passwords do not match.';
        } elseif (strlen($_POST['new_password']) < 6) {
            $error = 'New password must be at least 6 characters.';
        } else {
            $new_hash = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
            $stmt = $mysqli->prepare('UPDATE users SET password = ? WHERE id = ?');
            $stmt->bind_param('si', $new_hash, $_SESSION['user_id']);
            if ($stmt->execute()) {
                $success = 'Password changed successfully!';
            } else {
                $error = 'Failed to change password.';
            }
            $stmt->close();
        }
        $mysqli->close();
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>Change Password</title>
    <link href="css.css" rel="stylesheet" type="text/css"/>
</head>
<body>
    <div id="containerReg" style="display:flex;justify-content:center;align-items:center;min-height:100vh;">
        <div id="mainLogin" style="width:100%;max-width:400px;margin:auto;text-align:center;">
            <h2 style="margin-bottom:24px;">Change Password</h2>
            <?php if ($error): ?>
                <div style="color:red; text-align:center; margin-bottom:10px;">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>
            <?php if ($success): ?>
                <div style="color:green; text-align:center; margin-bottom:10px;">
                    <?php echo htmlspecialchars($success); ?>
                </div>
            <?php endif; ?>
            <form method="post" style="display:flex;flex-direction:column;align-items:center;gap:12px;">
                <label style="width:100%;text-align:left;">Current Password:</label>
                <input type="password" name="current_password" required style="width:120px;">
                <label style="width:100%;text-align:left;">New Password:</label>
                <input type="password" name="new_password" required style="width:120px;">
                <label style="width:100%;text-align:left;">Confirm New Password:</label>
                <input type="password" name="confirm_password" required style="width:120px;">
                <button type="submit" style="margin-top:10px;">Change Password</button>
            </form>
            <div style="margin-top:18px;"><a href="chat.php">Back to Chat</a></div>
        </div>
    </div>
</body>
</html>
