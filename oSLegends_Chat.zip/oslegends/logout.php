<?php
session_start();

if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $mysqli = new mysqli('localhost', 'root', '', 'oschat');
    if (!$mysqli->connect_errno) {
        $stmt = $mysqli->prepare('UPDATE users SET is_logged_in = 0, session_id = NULL WHERE id = ?');
        $stmt->bind_param('i', $user_id);
        $stmt->execute();
        $stmt->close();
        $mysqli->close();
    }
}

// Unset all session variables
$_SESSION = array();
// Destroy the session
session_destroy();
// Redirect to login page
header('Location: index.php');
exit;
