<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['Administrator', 'Super Moderator', 'Moderator', 'Female Moderator'])) {
    echo json_encode(['success' => false, 'error' => 'Permission denied.']);
    exit;
}

if (!isset($_GET['user_id']) || !is_numeric($_GET['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'No user ID provided.']);
    exit;
}

$user_id = intval($_GET['user_id']);
$mysqli = new mysqli('localhost', 'root', '', 'oschat');
if ($mysqli->connect_errno) {
    echo json_encode(['success' => false, 'error' => 'Database error.']);
    exit;
}

$stmt = $mysqli->prepare('SELECT bh.banned_at, u.username as banned_by FROM ban_history bh JOIN users u ON bh.banned_by_user_id = u.id WHERE bh.user_id = ? ORDER BY bh.banned_at DESC');
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();
$history = [];
while ($row = $result->fetch_assoc()) {
    $history[] = $row;
}
$stmt->close();
$mysqli->close();

echo json_encode(['success' => true, 'history' => $history]);
