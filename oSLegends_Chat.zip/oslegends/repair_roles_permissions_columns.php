<?php
// This script will drop corrupted columns and add the correct ones to roles_permissions
$mysqli = new mysqli('localhost', 'root', '', 'oschat');
if ($mysqli->connect_errno) {
    die('Database connection failed.');
}
$columns = [
    'username_colorame_color', 'text_colorcolor', 'avatarr'
];
foreach ($columns as $col) {
    $exists = $mysqli->query("SHOW COLUMNS FROM roles_permissions LIKE '$col'");
    if ($exists->num_rows > 0) {
        $mysqli->query("ALTER TABLE roles_permissions DROP COLUMN `$col`");
    }
}
// Now add correct columns if missing
$add = [
    'username_color' => ", ADD COLUMN username_color VARCHAR(8) DEFAULT '#FFC300' ",
    'text_color' => ", ADD COLUMN text_color VARCHAR(8) DEFAULT '#FFFFFF' ",
    'avatar' => ", ADD COLUMN avatar VARCHAR(128) DEFAULT NULL "
];
foreach ($add as $col => $sql) {
    $exists = $mysqli->query("SHOW COLUMNS FROM roles_permissions LIKE '$col'");
    if ($exists->num_rows === 0) {
        $mysqli->query("ALTER TABLE roles_permissions ADD COLUMN $col" . substr($sql, 18));
    }
}
$mysqli->close();
echo "roles_permissions columns repaired.";
