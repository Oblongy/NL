<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>oS Legends Chat - Forgot Password</title>
    <link href="css.css" rel="stylesheet" type="text/css"/>
</head>
<body>
    <div id="logoLogin"></div>
    <div id="containerReg">
        <div id="mainLogin">
            <div id="welcome">
                <p style="text-align:center;">Forgot Your Password?</p>
            </div>
            <form id="forgotpw" action="forgotpw.php" method="post" accept-charset="UTF-8">
                <fieldset style="text-align:center;">
                    <legend>Reset Password</legend>
                    <label for="email">Email:</label><br>
                    <input type="email" name="email" id="email" maxlength="100" required/><br>
                    <input type="submit" name="Submit" value="Send Reset Link"/>
                </fieldset>
            </form>
            <div id="loginLink">
                <p style="text-align:center;"><a href="index.php" style="link {color:#FFFF00;}">Back to Login</a></p>
            </div>
        </div>
    </div>
</body>
</html>
