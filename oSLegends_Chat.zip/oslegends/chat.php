<?php
session_start();
require_once 'session_check.php';
// Enforce session and ban check
if (!isset($_SESSION['user_id']) || !isset($_SESSION['username']) || !isset($_SESSION['role'])) {
    header('Location: index.php?session=invalid');
    exit;
}
if ($_SESSION['role'] === 'Banned') {
    session_destroy();
    header('Location: index.php?banned=1');
    exit;
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
        <script src="https://cdn.socket.io/4.7.5/socket.io.min.js"></script>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title>oS Legends Chat</title>
    <link href="css.css" rel="stylesheet" type="text/css"/>
    <!-- Style moved to css.css for chat layout fixes -->
</head>
<body>
    <div id="logoLogin"></div>
    <!-- User Profile Pop-out -->
    <div id="profile-popout" class="profile-popout">
        <div class="profile-popout-header">Your Profile <span id="close-profile-popout" class="close-profile-popout">&times;</span></div>
        <div class="profile-avatar">
            <?php
            $role = isset($_SESSION['role']) ? $_SESSION['role'] : '';
            $userId = isset($_SESSION['user_id']) ? intval($_SESSION['user_id']) : 0;
            $mysqli = new mysqli('localhost', 'root', '', 'oschat');
            $avatar = '';
            if ($mysqli && !$mysqli->connect_errno && $userId) {
                $stmt = $mysqli->prepare('SELECT rp.avatar FROM users u LEFT JOIN roles_permissions rp ON u.role = rp.role WHERE u.id = ?');
                $stmt->bind_param('i', $userId);
                $stmt->execute();
                $stmt->bind_result($avatar);
                $stmt->fetch();
                $stmt->close();
                $mysqli->close();
            }
            if (!$avatar) {
                if ($role === 'Super Administrator') {
                    $avatar = 'images/badges/super_admin.png';
                } else {
                    $avatar = 'images/badges/basic_user.png';
                }
            }
            $avatarSize = ($role === 'Super Administrator') ? 'width:29px;height:21px;' : 'width:64px;height:64px;border-radius:50%;';
            ?>
            <img src="<?php echo htmlspecialchars($avatar); ?>" alt="Avatar" style="<?php echo $avatarSize; ?>border:2px solid #fff;">
        </div>
        <div class="profile-info">
            <div class="profile-username"><?php echo htmlspecialchars($_SESSION['username']); ?></div>
            <div class="profile-role" style="color:<?php echo isset($_SESSION['role']) ? (['Administrator'=>'#FFC300','Super Moderator'=>'#3295FC','Moderator'=>'#2980b9','Female Moderator'=>'#fd7aee','Member'=>'#27ae60','Staff'=>'#16a085','Banned'=>'#f8ba5d','basic user'=>'#ffffff','System'=>'#b339ff'][$_SESSION['role']] ?? '#fff') : '#fff'; ?>;font-weight:bold;">
                <?php echo htmlspecialchars($_SESSION['role']); ?>
            </div>
            <div style="margin-top:14px;">
                <a href="change_password.php" style="color:#FFC300; font-weight:bold; text-decoration:underline;">Change Password</a>
            </div>
        </div>
    </div>
    <?php if (in_array($_SESSION['role'], ['Super Administrator','Administrator','Super Moderator','Moderator','Female Moderator'])): ?>
    <button id="mod-tools-btn" class="mod-tools-btn">Mod Tools</button>
    <div id="mod-tools-popout" class="mod-tools-popout">
        <div class="mod-tools-header" id="mod-tools-drag-handle" style="cursor:move;user-select:none;">Moderator Tools <span id="close-mod-tools" class="close-mod-tools">&times;</span></div>
        <form id="mod-tools-form" class="mod-tools-list" style="display:flex;flex-direction:column;gap:14px;">
            <label>Username:
                <input type="text" id="mod-username" name="username" style="width:90%;margin-top:4px;">
            </label>
            <label>Ban Reason:
                <input type="text" id="mod-ban-reason" name="ban_reason" style="width:90%;margin-top:4px;">
            </label>
            <label>Ban Timer (minutes):
                <select id="mod-ban-timer" name="ban_timer" style="width:94%;margin-top:4px;">
                    <option value="5">5 minutes</option>
                    <option value="10">10 minutes</option>
                    <option value="30">30 minutes</option>
                    <option value="60">1 hour</option>
                    <option value="120">2 hours</option>
                    <option value="240">4 hours</option>
                    <option value="360">6 hours</option>
                    <option value="720">12 hours</option>
                    <option value="1440">1 day</option>
                    <option value="2880">2 days</option>
                    <option value="4320">3 days</option>
                    <option value="5760">4 days</option>
                    <option value="7200">5 days</option>
                    <option value="8640">6 days</option>
                    <option value="10080">7 days (max)</option>
                    <?php if (isset($_SESSION['role']) && $_SESSION['role'] === 'Administrator'): ?>
                        <option value="permanent">Permanent</option>
                    <?php endif; ?>
                </select>
            </label>
            <button type="submit" style="margin-top:8px;">Ban User</button>
        </form>
    </div>
    <?php endif; ?>
    <div id="container">
        <div id="main">
            <h2 id="room-title" style="text-align:center;">oS Legends Chat</h2>
            <div style="display:flex;justify-content:center;align-items:center;gap:18px;margin-bottom:18px;">
                <label for="room-select" style="font-weight:bold;">Room:</label>
                <select id="room-select" style="font-size:1.1em;padding:4px 10px;"></select>
            </div>
            <div id="chatContainer">
                <div id="chat-messages"></div>
                <div id="userList">
                    <b>Users Online</b>
                    <ul id="userListUl" style="list-style-type:none; padding-left:0; margin-left:0;"></ul>
                </div>
            </div>
            <form id="chat-form">
                <input type="text" id="chat-input" placeholder="Type your message..." autocomplete="off">
                <button type="submit">Send</button>
            </form>
                <script>
                                                                                // --- Socket.IO for real-time private message clear ---
                                                                                const socket = io('http://localhost:3001'); // Adjust if your Node server is remote
                                                                                let myId = <?php echo (int)$_SESSION['user_id']; ?>;

                                                                // Always hide private message popup on page load
                                                                document.addEventListener('DOMContentLoaded', function() {
                                                                    var pmPopup = document.getElementById('private-message-popup');
                                                                    if (pmPopup) pmPopup.style.display = 'none';
                                                                });
                                                // --- Draggable Private Message Popup ---
                                                document.addEventListener('DOMContentLoaded', function() {
                                                    const popup = document.getElementById('private-message-popup');
                                                    const header = document.getElementById('private-message-header');
                                                    if (!popup || !header) return;
                                                    let offsetX = 0, offsetY = 0, isDragging = false;
                                                    let startX = 0, startY = 0;
                                                    header.style.cursor = 'move';
                                                    header.addEventListener('mousedown', function(e) {
                                                        isDragging = true;
                                                        startX = e.clientX;
                                                        startY = e.clientY;
                                                        const rect = popup.getBoundingClientRect();
                                                        offsetX = startX - rect.left;
                                                        offsetY = startY - rect.top;
                                                        document.body.style.userSelect = 'none';
                                                    });
                                                    document.addEventListener('mousemove', function(e) {
                                                        if (!isDragging) return;
                                                        let x = e.clientX - offsetX;
                                                        let y = e.clientY - offsetY;
                                                        // Keep popup within viewport
                                                        x = Math.max(0, Math.min(window.innerWidth - popup.offsetWidth, x));
                                                        y = Math.max(0, Math.min(window.innerHeight - popup.offsetHeight, y));
                                                        popup.style.left = x + 'px';
                                                        popup.style.top = y + 'px';
                                                        popup.style.right = '';
                                                        popup.style.bottom = '';
                                                        popup.style.position = 'fixed';
                                                    });
                                                    document.addEventListener('mouseup', function() {
                                                        isDragging = false;
                                                        document.body.style.userSelect = '';
                                                    });
                                                });
                                // Mod Tools form submit logic
                                const modToolsForm = document.getElementById('mod-tools-form');
                                if (modToolsForm) {
                                    modToolsForm.addEventListener('submit', function(e) {
                                        e.preventDefault();
                                        const username = document.getElementById('mod-username').value.trim();
                                        const reason = document.getElementById('mod-ban-reason').value.trim();
                                        const timer = document.getElementById('mod-ban-timer').value.trim();
                                        if (!username || !reason || !timer) {
                                            alert('Please fill in all fields.');
                                            return;
                                        }
                                        fetch('ban_user.php', {
                                            method: 'POST',
                                            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                                            body: `username=${encodeURIComponent(username)}&reason=${encodeURIComponent(reason)}&timer=${encodeURIComponent(timer)}`
                                        })
                                        .then(res => res.json())
                                        .then(data => {
                                            if (data.success) {
                                                alert('User banned successfully.');
                                                modToolsForm.reset();
                                                modPop.style.display = 'none';
                                            } else {
                                                alert(data.error || 'Failed to ban user.');
                                            }
                                        });
                                    });
                                }
                let currentRoomId = null;
                // --- Room logic ---
                // Store room password requirements
                let roomPasswordMap = {};
                let enteredRoomPasswords = {};
                function fetchMessages() {
                    if (!currentRoomId) return;
                    const formData = new FormData();
                    formData.append('room_id', currentRoomId);
                    if (roomPasswordMap[currentRoomId] && enteredRoomPasswords[currentRoomId]) {
                        formData.append('password', enteredRoomPasswords[currentRoomId]);
                    }
                    fetch('get_messages.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(res => res.json())
                    .then(data => {
                        const chatDiv = document.getElementById('chat-messages');
                        if (data.success) {
                            chatDiv.innerHTML = data.messages.map(renderMessage).join('');
                            chatDiv.scrollTop = chatDiv.scrollHeight;
                        } else if (data.error && data.error === 'Incorrect room password.') {
                            alert('Incorrect room password. Please try again.');
                            delete enteredRoomPasswords[currentRoomId];
                        } else {
                            chatDiv.innerHTML = '<span style="color:red;">' + (data.error || 'Failed to load messages.') + '</span>';
                        }
                    });
                }

                function loadRooms(selectedId) {
                    fetch('get_rooms.php')
                        .then(res => res.json())
                        .then(rooms => {
                            const select = document.getElementById('room-select');
                            select.innerHTML = '';
                            roomPasswordMap = {};
                            let defaultRoomId = null;
                            rooms.forEach(room => {
                                const opt = document.createElement('option');
                                opt.value = room.id;
                                opt.textContent = room.name + (room.has_password ? ' 🔒' : '');
                                // If selectedId is provided, select that room
                                if (selectedId && room.id == selectedId) opt.selected = true;
                                // Otherwise, select room with ID 1 if it exists
                                if (!selectedId && room.id == 1) {
                                    opt.selected = true;
                                    defaultRoomId = 1;
                                }
                                select.appendChild(opt);
                                roomPasswordMap[room.id] = room.has_password;
                            });
                            // If no selectedId and room 1 exists, set currentRoomId to 1
                            if (!selectedId && defaultRoomId !== null) {
                                currentRoomId = 1;
                                updateRoomTitle();
                                fetchMessages();
                                fetchUserList();
                            } else if (!selectedId && rooms.length > 0) {
                                // Fallback to first room if room 1 doesn't exist
                                currentRoomId = rooms[0].id;
                                updateRoomTitle();
                                fetchMessages();
                                fetchUserList();
                            }
                        });
                }
                function updateRoomTitle() {
                    const select = document.getElementById('room-select');
                    const title = document.getElementById('room-title');
                    const roomName = select.options[select.selectedIndex]?.text || 'Chat Room';
                    title.textContent = roomName;
                }
                document.getElementById('room-select').addEventListener('change', function() {
                    const selectedRoomId = this.value;
                    if (roomPasswordMap[selectedRoomId]) {
                        // Prompt for password if not already entered
                        if (!enteredRoomPasswords[selectedRoomId]) {
                            const pwd = prompt('This room is protected. Enter the room password:');
                            if (pwd === null) {
                                // User cancelled
                                // Revert selection
                                this.value = currentRoomId;
                                return;
                            }
                            enteredRoomPasswords[selectedRoomId] = pwd;
                        }
                    }
                    currentRoomId = selectedRoomId;
                    updateRoomTitle();
                    fetchMessages();
                    fetchUserList();
                });
                // Room creation removed from user chat UI
                // --- End room logic ---
                document.addEventListener('DOMContentLoaded', function() {
                    // Check session status on load
                    fetch('get_current_user.php')
                        .then(res => res.json())
                        .then(data => {
                            if (!data.username) {
                                alert('Session expired or invalid. Please log in again.');
                                window.location.href = 'index.php?session=expired';
                            }
                        });
                    // Load rooms on page load
                    loadRooms();
                // Mod Tools pop-out logic
                const modBtn = document.getElementById('mod-tools-btn');
                const modPop = document.getElementById('mod-tools-popout');
                const closeMod = document.getElementById('close-mod-tools');
                const dragHandle = document.getElementById('mod-tools-drag-handle');
                if (modBtn && modPop && closeMod && dragHandle) {
                    modBtn.addEventListener('click', function() {
                        modPop.style.display = 'block';
                    });
                    closeMod.addEventListener('click', function() {
                        modPop.style.display = 'none';
                    });
                    window.addEventListener('click', function(e) {
                        if (e.target !== modBtn && !modPop.contains(e.target)) {
                            modPop.style.display = 'none';
                        }
                    });

                    // --- Draggable logic for mod tools popout ---
                    let isDragging = false;
                    let dragOffsetX = 0;
                    let dragOffsetY = 0;

                    dragHandle.addEventListener('mousedown', function(e) {
                        isDragging = true;
                        const rect = modPop.getBoundingClientRect();
                        dragOffsetX = e.clientX - rect.left;
                        dragOffsetY = e.clientY - rect.top;
                        document.body.style.userSelect = 'none';
                    });

                    document.addEventListener('mousemove', function(e) {
                        if (!isDragging) return;
                        modPop.style.left = (e.clientX - dragOffsetX) + 'px';
                        modPop.style.top = (e.clientY - dragOffsetY) + 'px';
                        modPop.style.right = '';
                        modPop.style.bottom = '';
                        modPop.style.position = 'fixed';
                    });

                    document.addEventListener('mouseup', function() {
                        isDragging = false;
                        document.body.style.userSelect = '';
                    });
                    // Reset position when opening
                    modBtn.addEventListener('click', function() {
                        modPop.style.left = '';
                        modPop.style.top = '';
                        modPop.style.right = '40px';
                        modPop.style.top = '80px';
                        modPop.style.position = 'fixed';
                    });
                    // --- End draggable logic ---
                }

                // User Profile pop-out logic
                const profileBtn = document.getElementById('profile-btn');
                const profilePop = document.getElementById('profile-popout');
                const closeProfile = document.getElementById('close-profile-popout');
                if (profileBtn && profilePop && closeProfile) {
                    profileBtn.addEventListener('click', function() {
                        profilePop.style.display = 'flex';
                    });
                    closeProfile.addEventListener('click', function() {
                        profilePop.style.display = 'none';
                    });
                    window.addEventListener('click', function(e) {
                        if (e.target !== profileBtn && !profilePop.contains(e.target)) {
                            profilePop.style.display = 'none';
                        }
                    });
                }
                const currentUserId = <?php echo $_SESSION['user_id']; ?>;

                // Role color mapping (dynamic)
                let roleColors = {};
                let roleTextColors = {};
                fetch('get_role_colors.php')
                    .then(res => res.json())
                    .then(colors => {
                        Object.keys(colors).forEach(role => {
                            roleColors[role] = colors[role].username_color || '#FFC300';
                            roleTextColors[role] = colors[role].text_color || '#FFFFFF';
                        });
                    });

                function escapeHtml(text) {
                    var map = {
                        '&': '&amp;',
                        '<': '&lt;',
                        '>': '&gt;',
                        '"': '&quot;',
                        "'": '&#039;'
                    };
                    return text.replace(/[&<>"'/]/g, function(m) { return map[m]; });
                }

                function renderMessage(msg) {
                    const usernameColor = roleColors[msg.role] || '#FFC300';
                    const textColor = roleTextColors[msg.role] || '#FFFFFF';
                    return `<span style="font-weight:bold;color:${usernameColor};">${escapeHtml(msg.username)}</span>: <span style="color:${textColor};">${escapeHtml(msg.message)}</span><br>`;
                }

                function fetchMessages() {
                    if (!currentRoomId) return;
                    const formData = new FormData();
                    formData.append('room_id', currentRoomId);
                    if (roomPasswordMap[currentRoomId] && enteredRoomPasswords[currentRoomId]) {
                        formData.append('password', enteredRoomPasswords[currentRoomId]);
                    }
                    fetch('get_messages.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(res => res.json())
                    .then(data => {
                        const chatDiv = document.getElementById('chat-messages');
                        if (data.success) {
                            chatDiv.innerHTML = data.messages.map(renderMessage).join('');
                            chatDiv.scrollTop = chatDiv.scrollHeight;
                        } else if (data.error && data.error === 'Incorrect room password.') {
                            alert('Incorrect room password. Please try again.');
                            delete enteredRoomPasswords[currentRoomId];
                        } else {
                            chatDiv.innerHTML = '<span style="color:red;">' + (data.error || 'Failed to load messages.') + '</span>';
                        }
                    });
                }

                document.getElementById('chat-form').addEventListener('submit', function(e) {
                    e.preventDefault();
                    const input = document.getElementById('chat-input');
                    const message = input.value.trim();
                    if (!message) return;

                    // Only allow sending if session is valid
                    fetch('get_current_user.php')
                        .then(res => res.json())
                        .then(data => {
                            if (!data.username) {
                                alert('Session expired or invalid. Please log in again.');
                                window.location.href = 'index.php?session=expired';
                                return;
                            }

                            // Command handling
                            if (message.startsWith('/unmute ')) {
                                const parts = message.split(' ');
                                if (parts.length >= 2) {
                                    const usernameToUnmute = parts[1];
                                    fetch('unmute_user.php', {
                                        method: 'POST',
                                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                                        body: 'username=' + encodeURIComponent(usernameToUnmute)
                                    })
                                    .then(res => res.json())
                                    .then(data => {
                                        if (data.success) {
                                            input.value = '';
                                            alert('User ' + usernameToUnmute + ' has been unmuted.');
                                            fetchUserList();
                                        } else {
                                            alert(data.error || 'Failed to unmute user.');
                                        }
                                    });
                                }
                                return;
                            }

                            if (message.startsWith('/ban ')) {
                                const parts = message.split(' ');
                                if (parts.length >= 2) {
                                    const usernameToBan = parts[1];
                                    fetch('ban_user.php', {
                                        method: 'POST',
                                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                                        body: 'username=' + encodeURIComponent(usernameToBan)
                                    })
                                    .then(res => res.json())
                                    .then(data => {
                                        if (data.success) {
                                            input.value = '';
                                            alert('User ' + usernameToBan + ' has been banned.');
                                            fetchUserList();
                                        } else {
                                            alert(data.error || 'Failed to ban user.');
                                        }
                                    });
                                }
                                return;
                            }

                            if (message.startsWith('/mute ')) {
                                const parts = message.split(' ');
                                if (parts.length >= 2) {
                                    const usernameToMute = parts[1];
                                    fetch('mute_user.php', {
                                        method: 'POST',
                                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                                        body: 'username=' + encodeURIComponent(usernameToMute)
                                    })
                                    .then(res => res.json())
                                    .then(data => {
                                        if (data.success) {
                                            input.value = '';
                                            alert('User ' + usernameToMute + ' has been muted for 5 minutes.');
                                            fetchUserList();
                                        } else {
                                            alert(data.error || 'Failed to mute user.');
                                        }
                                    });
                                }
                                return;
                            }

                            // Normal message
                            fetch('send_message.php', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                                body: 'message=' + encodeURIComponent(message) + '&room_id=' + encodeURIComponent(currentRoomId)
                            })
                            .then(res => res.json())
                            .then(data => {
                                if (data.success) {
                                    input.value = '';
                                    fetchMessages();
                                } else if (data.error) {
                                    alert(data.error);
                                }
                            });
                        });
                });

                // Poll for new messages every 2 seconds
                setInterval(fetchMessages, 2000);
                // Initial fetch
                fetchMessages();

                // --- User list logic moved here ---
                function updateUserList(users) {
                    var ul = document.getElementById('userListUl');
                    ul.innerHTML = '';
                    users.forEach(function(user) {
                        var li = document.createElement('li');
                        var color = user.username_color || '#FFC300';
                        var style = '';
                        var avatarStyle = 'width: 20px; height: 20px; margin-right: 5px; vertical-align: middle;';
                        switch (user.role) {
                            case 'Super Administrator':
                                avatarStyle = 'width: 29px; height: 21px; margin-right: 5px; vertical-align: middle;'; break;
                            case 'Administrator':
                                style = 'font-weight:bold;'; avatarStyle = 'width: 29px; height: 21px; margin-right: 5px; vertical-align: middle;'; break;
                            case 'Super Moderator':
                                style = 'font-style:italic;'; avatarStyle = 'width: 29px; height: 21px; margin-right: 5px; vertical-align: middle;'; break;
                            case 'Moderator':
                                avatarStyle = 'width: 29px; height: 21px; margin-right: 5px; vertical-align: middle;'; break;
                            case 'Female Moderator':
                                avatarStyle = 'width: 29px; height: 21px; margin-right: 5px; vertical-align: middle;'; break;
                            case 'Member':
                                avatarStyle = 'width: 29px; height: 21px; margin-right: 5px; vertical-align: middle;'; break;
                            case 'Banned':
                                style = 'text-decoration:line-through;'; break;
                            case 'basic user':
                                avatarStyle = 'width: 29px; height: 21px; margin-right: 5px; vertical-align: middle;'; break;
                        }
                        if (user.id == currentUserId) {
                            li.innerHTML = `<img src="${user.avatar}" style="${avatarStyle}"> <span style="color:${color};${style}">${user.username}</span>`;
                        } else {
                            li.innerHTML = `<img src="${user.avatar}" style="${avatarStyle}"> <a href="#" class="private-message-link" data-user-id="${user.id}" data-username="${user.username}" style="color:${color};${style}">${user.username}</a>`;
                        }
                        ul.appendChild(li);
                    });
                }

                function fetchUserList() {
                    fetch('get_users.php')
                        .then(res => res.json())
                        .then(users => {
                            updateUserList(users);
                        })
                        .catch(() => updateUserList([]));
                }

                // Poll for user list every 5 seconds
                fetchUserList();
                setInterval(fetchUserList, 5000);
                // --- End user list logic ---

                // --- Private messaging logic ---
                let currentRecipientId = null;
                let privateMessageInterval = null;

                document.getElementById('userListUl').addEventListener('click', function(e) {
                    if (e.target.classList.contains('private-message-link')) {
                        e.preventDefault();
                        const userId = e.target.dataset.userId;
                        const username = e.target.dataset.username;
                        openPrivateMessage(userId, username);
                    }
                });

                function openPrivateMessage(userId, username) {
                    currentRecipientId = userId;
                    document.getElementById('private-message-username').innerText = username;
                    document.getElementById('private-message-recipient-id').value = userId;
                    document.getElementById('private-message-popup').style.display = 'block';
                    fetchPrivateMessages();
                    if (privateMessageInterval) {
                        clearInterval(privateMessageInterval);
                    }
                    privateMessageInterval = setInterval(fetchPrivateMessages, 2000);
                }

                function closePrivateMessage() {
                    const toId = document.getElementById('private-message-recipient-id').value;
                    currentRecipientId = null;
                    document.getElementById('private-message-popup').style.display = 'none';
                    // Clear the chat area when closed
                    const messagesDiv = document.getElementById('private-message-messages');
                    if (messagesDiv) messagesDiv.innerHTML = '';
                    if (privateMessageInterval) {
                        clearInterval(privateMessageInterval);
                    }
                    // Signal the other user to clear their chat
                    if (toId) {
                        socket.emit('pm-close', { from: myId, to: toId });
                    }
                }

                // Listen for clear signal from the other user
                socket.on('pm-clear', function(data) {
                    // Only clear if the current user is the recipient
                    if (data.to == myId) {
                        document.getElementById('private-message-popup').style.display = 'none';
                        const messagesDiv = document.getElementById('private-message-messages');
                        if (messagesDiv) messagesDiv.innerHTML = '';
                        if (privateMessageInterval) clearInterval(privateMessageInterval);
                    }
                });

                document.getElementById('close-private-message').addEventListener('click', closePrivateMessage);

                function fetchPrivateMessages() {
                    if (!currentRecipientId) return;
                    fetch('get_private_messages.php?user_id=' + currentRecipientId)
                        .then(res => res.json())
                        .then(data => {
                            console.log('Private messages response:', data);
                            if (data.success) {
                                const messagesDiv = document.getElementById('private-message-messages');
                                messagesDiv.innerHTML = data.messages.map(renderPrivateMessage).join('');
                                messagesDiv.scrollTop = messagesDiv.scrollHeight;
                            }
                        });
                }

                function renderPrivateMessage(msg) {
                    // Log the message object for debugging
                    console.log('Rendering message:', msg);
                    // Use sender_username, username, or fallback
                    const name = msg.sender_username || msg.username || 'Unknown';
                    return `<div><strong>${name}:</strong> ${msg.message}</div>`;
                }

                document.getElementById('private-message-form').addEventListener('submit', function(e) {
                    e.preventDefault();
                    const input = document.getElementById('private-message-input');
                    const message = input.value.trim();
                    const recipientId = document.getElementById('private-message-recipient-id').value;
                    if (!message || !recipientId) return;

                    fetch('send_private_message.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: `recipient_id=${recipientId}&message=${encodeURIComponent(message)}`
                    })
                    .then(res => res.json())
                    .then(data => {
                        if (data.success) {
                            input.value = '';
                            fetchPrivateMessages();
                        }
                    });
                    return false;
                });
                // --- End private messaging logic ---

                // --- New private message polling ---
                function checkForNewPrivateMessages() {
                    fetch('get_new_private_messages.php')
                        .then(res => res.json())
                        .then(data => {
                            if (data.success && data.messages.length > 0) {
                                const lastMessage = data.messages[data.messages.length - 1];
                                openPrivateMessage(lastMessage.sender_id, lastMessage.sender_username);
                            }
                        });
                }

                setInterval(checkForNewPrivateMessages, 3000); // Check every 3 seconds
                // --- End new private message polling ---

                // --- User activity heartbeat ---
                function updateUserActivity() {
                    fetch('update_activity.php', { method: 'POST' });
                }
                updateUserActivity();
                setInterval(updateUserActivity, 5000); // Update every 5 seconds
                // --- End user activity heartbeat ---
                });
                </script>
            <div style="text-align:center; margin-top:20px;">
                <a href="logout.php" class="logout-btn-inline">Logout</a>
                <button id="profile-btn" class="profile-btn-inline" style="margin-left:18px;">Profile</button>
            </div>
        </div>
    </div>
    <div id="private-message-popup" class="private-message-popup">
        <div id="private-message-header" class="private-message-header">
            <span id="private-message-username"></span>
            <button type="button" id="close-private-message" class="close-private-message">Close</button>
        </div>
        <div id="private-message-messages" class="private-message-messages"></div>
        <form id="private-message-form" class="private-message-form">
            <input type="text" id="private-message-input" placeholder="Type a message..."/>
            <button type="submit" id="send-private-message">Send</button>
            <input type="hidden" id="private-message-recipient-id" />
        </form>
    </div>
    <!-- Removed legacy JS and duplicate sendMessage logic. All chat sending is handled by the chat-form submit event above. -->
</body>
</html>