<?php
// ban_user.php - Ban a user by username (POST: username)
session_start();
// CSRF token generation
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
// Session timeout management
$timeout_duration = 900; // 15 minutes
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $timeout_duration) {
    session_unset();
    session_destroy();
    echo json_encode(['success' => false, 'error' => 'Session timed out.']);
    exit;
}
$_SESSION['LAST_ACTIVITY'] = time();
header('Content-Type: application/json');

// Only allow specific roles to ban users
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || !in_array($_SESSION['role'], ['Administrator', 'Moderator', 'Super Moderator', 'Female Moderator'])) {
    echo json_encode(['success' => false, 'error' => 'Permission denied.']);
    exit;
}



if (!isset($_POST['username']) || trim($_POST['username']) === '') {
    echo json_encode(['success' => false, 'error' => 'No username provided.']);
    exit;
}
if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    echo json_encode(['success' => false, 'error' => 'Invalid CSRF token.']);
    exit;
}
$username = htmlspecialchars(trim($_POST['username']), ENT_QUOTES, 'UTF-8');
// Optionally, restrict allowed characters for usernames (alphanumeric, underscore, dash, dot)
if (!preg_match('/^[\w\-\.]{3,32}$/', $username)) {
    echo json_encode(['success' => false, 'error' => 'Invalid username format.']);
    exit;
}

$mysqli = new mysqli('localhost', 'root', '', 'oschat');
if ($mysqli->connect_errno) {
    echo json_encode(['success' => false, 'error' => 'Database error.']);
    exit;
}

// Role hierarchy
$roles = [
    'Administrator' => 3,
    'Super Moderator' => 2,
    'Moderator' => 1,
    'Female Moderator' => 1,
    'Member' => 0,
    'basic user' => 0
];

$currentUserRole = $_SESSION['role'];

// Get target user's role
$stmt_get_role = $mysqli->prepare('SELECT role FROM users WHERE username = ?');
$stmt_get_role->bind_param('s', $username);
$stmt_get_role->execute();
$stmt_get_role->bind_result($targetUserRole);

if ($stmt_get_role->fetch()) {
    $stmt_get_role->close();

    // Check if the current user can ban the target user
    if ($roles[$currentUserRole] <= $roles[$targetUserRole] && $currentUserRole !== 'Administrator') {
        echo json_encode(['success' => false, 'error' => 'You cannot ban a user with the same or higher role.']);
        exit;
    }
} else {
    $stmt_get_role->close();
    echo json_encode(['success' => false, 'error' => 'User not found.']);
    exit;
}

// Set the user's role to 'Banned'
$role = 'Banned';
$stmt = $mysqli->prepare('UPDATE users SET role = ? WHERE username = ?');
$stmt->bind_param('ss', $role, $username);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    // Get the user ID of the banned user
    $stmt_get_id = $mysqli->prepare('SELECT id FROM users WHERE username = ?');
    $stmt_get_id->bind_param('s', $username);
    $stmt_get_id->execute();
    $stmt_get_id->bind_result($banned_user_id);
    $stmt_get_id->fetch();
    $stmt_get_id->close();

    // Log the ban
    $banned_by_user_id = $_SESSION['user_id'];
    $stmt_log = $mysqli->prepare('INSERT INTO ban_history (user_id, banned_by_user_id) VALUES (?, ?)');
    $stmt_log->bind_param('ii', $banned_user_id, $banned_by_user_id);
    $stmt_log->execute();
    $stmt_log->close();

    // Destroy the session of the banned user by deleting their session file
    $sessionDir = __DIR__ . '/sessions/';
    if (is_dir($sessionDir)) {
        foreach (glob($sessionDir . 'sess_*') as $sessFile) {
            $sessData = @file_get_contents($sessFile);
            if ($sessData !== false && strpos($sessData, 'user_id|i:' . $banned_user_id . ';') !== false) {
                @unlink($sessFile);
            }
        }
    }

    // Insert system bot message
    $botUsername = 'System';
    $botRole = 'System';
    $botMessage = $username . ', has been banned from the chat.';
    $stmt2 = $mysqli->prepare('INSERT INTO messages (user_id, username, role, message) VALUES (?, ?, ?, ?)');
    $botUserId = 0;
    $stmt2->bind_param('isss', $botUserId, $botUsername, $botRole, $botMessage);
    $stmt2->execute();
    $stmt2->close();
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'error' => 'Failed to ban user. They may already be banned or the user does not exist.']);
}
$stmt->close();
$mysqli->close();
