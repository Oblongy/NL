<?php
// unmute_user.php - Unmute a user by username (POST: username)
session_start();
header('Content-Type: application/json');

// Only allow specific roles to unmute users
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || !in_array($_SESSION['role'], ['Administrator', 'Moderator', 'Super Moderator', 'Female Moderator'])) {
    echo json_encode(['success' => false, 'error' => 'Permission denied.']);
    exit;
}

if (!isset($_POST['username']) || trim($_POST['username']) === '') {
    echo json_encode(['success' => false, 'error' => 'No username provided.']);
    exit;
}

$username = trim($_POST['username']);
$mysqli = new mysqli('localhost', 'root', '', 'oschat');
if ($mysqli->connect_errno) {
    echo json_encode(['success' => false, 'error' => 'Database error.']);
    exit;
}

// Find user id
$stmt = $mysqli->prepare('SELECT id FROM users WHERE username = ?');
$stmt->bind_param('s', $username);
$stmt->execute();
$stmt->bind_result($user_id);
if ($stmt->fetch()) {
    $stmt->close();
    // Remove mute record
    $stmt2 = $mysqli->prepare('DELETE FROM mutes WHERE user_id = ?');
    $stmt2->bind_param('i', $user_id);
    $stmt2->execute();
    $stmt2->close();
    // System message
    $botUsername = 'System';
    $botRole = 'System';
    $botMessage = $username . ' has been unmuted.';
    $stmt3 = $mysqli->prepare('INSERT INTO messages (user_id, username, role, message) VALUES (?, ?, ?, ?)');
    $botUserId = 0;
    $stmt3->bind_param('isss', $botUserId, $botUsername, $botRole, $botMessage);
    $stmt3->execute();
    $stmt3->close();
    echo json_encode(['success' => true]);
} else {
    $stmt->close();
    echo json_encode(['success' => false, 'error' => 'User not found.']);
}
$mysqli->close();
