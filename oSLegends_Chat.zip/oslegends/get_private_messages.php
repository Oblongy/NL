<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Not logged in']);
    exit;
}

if (!isset($_GET['user_id']) || !is_numeric($_GET['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Invalid user ID']);
    exit;
}

$current_user_id = $_SESSION['user_id'];
$other_user_id = intval($_GET['user_id']);

$mysqli = new mysqli('localhost', 'root', '', 'oschat');
if ($mysqli->connect_errno) {
    echo json_encode(['success' => false, 'error' => 'Database error']);
    exit;
}

$stmt = $mysqli->prepare('SELECT pm.sender_id, pm.message, u.username as sender_username FROM private_messages pm JOIN users u ON pm.sender_id = u.id WHERE (pm.sender_id = ? AND pm.recipient_id = ?) OR (pm.sender_id = ? AND pm.recipient_id = ?) ORDER BY pm.id ASC');
$stmt->bind_param('iiii', $current_user_id, $other_user_id, $other_user_id, $current_user_id);
$stmt->execute();
$result = $stmt->get_result();
$messages = [];
while ($row = $result->fetch_assoc()) {
    $messages[] = $row;
}
$stmt->close();
$mysqli->close();

echo json_encode(['success' => true, 'messages' => $messages]);
