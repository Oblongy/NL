<?php
// update_role.php - Change a user's role (admin only)
session_start();
// CSRF token generation
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
// Session timeout management
$timeout_duration = 900; // 15 minutes
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $timeout_duration) {
    session_unset();
    session_destroy();
    header('Location: index.php?timeout=1');
    exit;
}
$_SESSION['LAST_ACTIVITY'] = time();
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}
$mysqli = new mysqli('localhost', 'root', '', 'oschat');
if ($mysqli->connect_errno) {
    die('Database connection failed.');
}
// Check if current user is admin
$stmt = $mysqli->prepare('SELECT role FROM users WHERE id = ?');
$stmt->bind_param('i', $_SESSION['user_id']);
$stmt->execute();
$stmt->bind_result($role);
$stmt->fetch();
$stmt->close();
if ($role !== 'Administrator') {
    $mysqli->close();
    header('Location: index.php');
    exit;
}
// Update role
if (isset($_POST['user_id'], $_POST['new_role'], $_POST['csrf_token'])) {
    // Validate CSRF token
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $mysqli->close();
        die('Invalid CSRF token.');
    }
    $user_id = intval($_POST['user_id']);
    $new_role = $_POST['new_role'];
    // Check if the new role exists in roles_permissions table
    $stmt = $mysqli->prepare('SELECT COUNT(*) FROM roles_permissions WHERE role = ?');
    $stmt->bind_param('s', $new_role);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();
    if ($count > 0) {
        $stmt = $mysqli->prepare('UPDATE users SET role = ? WHERE id = ?');
        $stmt->bind_param('si', $new_role, $user_id);
        $stmt->execute();
        $stmt->close();
        // Regenerate CSRF token after successful POST
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
}
$mysqli->close();
header('Location: Admin.php');
exit;

// In your HTML form, add:
// <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
