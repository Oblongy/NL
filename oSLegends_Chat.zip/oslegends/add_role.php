<?php
// add_role.php - Add a new role to roles_permissions table
session_start();
// CSRF token generation
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
// Session timeout management
$timeout_duration = 900; // 15 minutes
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $timeout_duration) {
    session_unset();
    session_destroy();
    header('Location: index.php?timeout=1');
    exit;
}
$_SESSION['LAST_ACTIVITY'] = time();
require_once 'session_check.php';
if (!isset($_SESSION['user_id']) || !isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}
$stmt = $mysqli->prepare('SELECT role FROM users WHERE id = ?');
$stmt->bind_param('i', $_SESSION['user_id']);
$stmt->execute();
$stmt->bind_result($role);
$stmt->fetch();
$stmt->close();
if ($role !== 'Administrator') {
    $mysqli->close();
    header('Location: index.php');
    exit;
}
$mysqli = new mysqli('localhost', 'root', '', 'oschat');
if ($mysqli->connect_errno) {
    die('Database connection failed.');
}
$avatar = isset($_POST['avatar']) ? trim($_POST['avatar']) : null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['role_name'], $_POST['csrf_token'])) {
    // Validate CSRF token
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $mysqli->close();
        die('Invalid CSRF token.');
    }
    // Sanitize and validate role name
    $role_name = htmlspecialchars(trim($_POST['role_name']), ENT_QUOTES, 'UTF-8');
    // Validate color codes (simple hex check)
    $username_color = isset($_POST['username_color']) && preg_match('/^#[a-fA-F0-9]{6}$/', $_POST['username_color']) ? $_POST['username_color'] : '#FFC300';
    $text_color = isset($_POST['text_color']) && preg_match('/^#[a-fA-F0-9]{6}$/', $_POST['text_color']) ? $_POST['text_color'] : '#FFFFFF';
    // Validate avatar (optional, allow only safe characters)
    if ($avatar !== null && !preg_match('/^[\w\-\.]+$/', $avatar)) {
        $avatar = null;
    }
    if ($role_name !== '') {
        $stmt = $mysqli->prepare('INSERT INTO roles_permissions (role, can_ban_users, can_delete_rooms, can_create_rooms, can_mute_users, can_change_roles, username_color, text_color, avatar) VALUES (?, 0, 0, 0, 0, 0, ?, ?, ?)');
        $stmt->bind_param('ssss', $role_name, $username_color, $text_color, $avatar);
        $stmt->execute();
        $stmt->close();
        // Regenerate CSRF token after successful POST
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        header('Location: role_management.php?added=1');
        exit;
    }
}
$mysqli->close();
header('Location: role_management.php?added=0');
exit;
// In your HTML form, add:
// <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">