<?php
// get_role_colors.php - Returns a JSON map of role => [username_color, text_color]
$mysqli = new mysqli('localhost', 'root', '', 'oschat');
if ($mysqli->connect_errno) {
    echo json_encode([]);
    exit;
}
$result = $mysqli->query('SELECT role, username_color, text_color FROM roles_permissions');
$colors = [];
while ($row = $result->fetch_assoc()) {
    $colors[$row['role']] = [
        'username_color' => $row['username_color'] ?? '#FFC300',
        'text_color' => $row['text_color'] ?? '#FFFFFF'
    ];
}
echo json_encode($colors);
$mysqli->close();
