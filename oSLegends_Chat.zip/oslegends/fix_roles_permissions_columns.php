<?php
// Run this script to fix missing columns in roles_permissions table
$mysqli = new mysqli('localhost', 'root', '', 'oschat');
if ($mysqli->connect_errno) {
    die('Database connection failed.');
}
$columns = [
    'username_color' => ", ADD COLUMN username_color VARCHAR(8) DEFAULT '#FFC300' ",
    'text_color' => ", ADD COLUMN text_color VARCHAR(8) DEFAULT '#FFFFFF' ",
    'avatar' => ", ADD COLUMN avatar VARCHAR(128) DEFAULT NULL "
];
foreach ($columns as $col => $sql) {
    $exists = $mysqli->query("SHOW COLUMNS FROM roles_permissions LIKE '$col'");
    if ($exists->num_rows === 0) {
        $mysqli->query("ALTER TABLE roles_permissions ADD COLUMN $col" . substr($sql, 18));
    }
}
$mysqli->close();
echo "roles_permissions columns fixed.";
