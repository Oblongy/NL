<?php
// Run this script once to create the roles_permissions table
$mysqli = new mysqli('localhost', 'root', '', 'oschat');
if ($mysqli->connect_errno) {
    die('Database connection failed.');
}
$sql = "CREATE TABLE IF NOT EXISTS roles_permissions (
    role VARCHAR(32) PRIMARY KEY,
    can_ban_users TINYINT(1) DEFAULT 0,
    can_delete_rooms TINYINT(1) DEFAULT 0,
    can_create_rooms TINYINT(1) DEFAULT 0,
    can_mute_users TINYINT(1) DEFAULT 0,
    can_change_roles TINYINT(1) DEFAULT 0,
    username_color VARCHAR(8) DEFAULT '#FFC300',
    text_color VARCHAR(8) DEFAULT '#FFFFFF',
    avatar VARCHAR(128) DEFAULT NULL
)";
if ($mysqli->query($sql)) {
    echo "roles_permissions table created or already exists.";
} else {
    echo "Error: " . $mysqli->error;
}
$mysqli->close();
