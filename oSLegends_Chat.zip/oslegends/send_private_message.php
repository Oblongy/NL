<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Not logged in']);
    exit;
}

if (!isset($_POST['recipient_id']) || !is_numeric($_POST['recipient_id']) || !isset($_POST['message']) || trim($_POST['message']) === '') {
    echo json_encode(['success' => false, 'error' => 'Invalid input']);
    exit;
}

$sender_id = $_SESSION['user_id'];
$recipient_id = intval($_POST['recipient_id']);
$message = trim($_POST['message']);

$mysqli = new mysqli('localhost', 'root', '', 'oschat');
if ($mysqli->connect_errno) {
    echo json_encode(['success' => false, 'error' => 'Database error']);
    exit;
}

$stmt = $mysqli->prepare('INSERT INTO private_messages (sender_id, recipient_id, message) VALUES (?, ?, ?)');
$stmt->bind_param('iis', $sender_id, $recipient_id, $message);
$stmt->execute();
$stmt->close();
$mysqli->close();

echo json_encode(['success' => true]);
