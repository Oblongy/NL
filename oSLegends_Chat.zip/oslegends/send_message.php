<?php
// send_message.php - Store a chat message in the database
session_start();
header('Content-Type: application/json');
if (!isset($_SESSION['user_id'])) {
    echo json_encode([
        'success' => false,
        'error' => 'Not logged in',
        'session' => $_SESSION,
        'cookies' => $_COOKIE
    ]);
    exit;
}

// Spam control
$max_messages = 5; // Max messages in...
$time_period = 10; // ...this many seconds

if (!isset($_SESSION['message_timestamps'])) {
    $_SESSION['message_timestamps'] = [];
}

// Remove old timestamps
$now = time();
$_SESSION['message_timestamps'] = array_filter($_SESSION['message_timestamps'], function($timestamp) use ($now, $time_period) {
    return ($now - $timestamp) < $time_period;
});

if (count($_SESSION['message_timestamps']) >= $max_messages) {
    echo json_encode(['success' => false, 'error' => 'You are sending messages too quickly. Please wait a moment.']);
    exit;
}

$_SESSION['message_timestamps'][] = $now;
$message = isset($_POST['message']) ? trim($_POST['message']) : '';
if ($message === '') {
    echo json_encode(['success' => false, 'error' => 'Empty message']);
    exit;
}
if (!isset($_POST['room_id']) || !is_numeric($_POST['room_id'])) {
    echo json_encode(['success' => false, 'error' => 'Room ID required.']);
    exit;
}
$room_id = intval($_POST['room_id']);
$mysqli = new mysqli('localhost', 'root', '', 'oschat');
if ($mysqli->connect_errno) {
    echo json_encode(['success' => false, 'error' => 'Database error']);
    exit;
}
$stmt = $mysqli->prepare('SELECT username, role FROM users WHERE id = ?');
$stmt->bind_param('i', $_SESSION['user_id']);
$stmt->execute();
$stmt->bind_result($username, $role);
$stmt->fetch();
$stmt->close();

if ($role === 'Banned') {
    echo json_encode(['success' => false, 'error' => 'You are banned and cannot send messages.']);
    exit;
}

// Check if user is muted
$mysqli->query('CREATE TABLE IF NOT EXISTS mutes (user_id INT PRIMARY KEY, muted_until DATETIME)');
$stmt_mute = $mysqli->prepare('SELECT muted_until FROM mutes WHERE user_id = ?');
$stmt_mute->bind_param('i', $_SESSION['user_id']);
$stmt_mute->execute();
$stmt_mute->bind_result($muted_until);
if ($stmt_mute->fetch()) {
    if (strtotime($muted_until) > time()) {
        $stmt_mute->close();
        $mysqli->close();
        echo json_encode(['success' => false, 'error' => 'You are muted until ' . $muted_until]);
        exit;
    }
}
$stmt_mute->close();

$message = trim($_POST['message']);
$stmt = $mysqli->prepare('INSERT INTO messages (user_id, username, role, message, room_id) VALUES (?, ?, ?, ?, ?)');
$stmt->bind_param('isssi', $_SESSION['user_id'], $username, $role, $message, $room_id);
$stmt->execute();
$stmt->close();
$mysqli->close();
echo json_encode(['success' => true]);
