<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    exit;
}

$user_id = $_SESSION['user_id'];

$mysqli = new mysqli('localhost', 'root', '', 'oschat');
if ($mysqli->connect_errno) {
    exit;
}

$stmt = $mysqli->prepare('UPDATE users SET last_activity = NOW() WHERE id = ?');
$stmt->bind_param('i', $user_id);
$stmt->execute();
$stmt->close();

$mysqli->close();
?>