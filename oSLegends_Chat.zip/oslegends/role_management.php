<?php
session_start();
require_once 'session_check.php';
if (!isset($_SESSION['user_id']) || !isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}
$mysqli = new mysqli('localhost', 'root', '', 'oschat');
if ($mysqli->connect_errno) {
    die('Database connection failed.');
}
// Fetch all roles and permissions
$result = $mysqli->query('SELECT * FROM roles_permissions');
$roles = [];
while ($row = $result->fetch_assoc()) {
    $roles[] = $row;
}
$mysqli->close();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Role Management</title>
    <link href="css.css" rel="stylesheet" type="text/css"/>
    <style>
        body {
            background: #181818;
            color: #fff;
            font-family: 'Segoe UI', Arial, sans-serif;
        }
        .role-container {
            background: #23272e;
            border-radius: 16px;
            box-shadow: 0 2px 16px #000a;
            width: 90%;
            max-width: 900px;
            margin: 40px auto 0 auto;
            padding: 32px 28px 28px 28px;
        }
        .role-header {
            text-align: center;
            color: #FFC300;
            font-size: 2.2em;
            margin: 0 0 32px 0;
            letter-spacing: 1px;
            font-weight: bold;
        }
        .role-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            background: #23272e;
            color: #fff;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 2px 8px #0006;
        }
        .role-table th, .role-table td {
            border: none;
            padding: 16px 10px;
            text-align: center;
        }
        .role-table th {
            background: #2c2f36;
            font-size: 1.08em;
            letter-spacing: 1px;
            color: #FFC300;
        }
        .role-table tr:nth-child(even) {
            background: #23272e;
        }
        .role-table tr:nth-child(odd) {
            background: #20232a;
        }
        .role-table td:first-child {
            font-weight: bold;
            color: #FFC300;
        }
        .role-form {
            text-align: center;
            margin: 0;
        }
        .role-form button {
            margin-top: 24px;
            padding: 12px 32px;
            font-size: 1.1em;
            background: #FFC300;
            color: #181818;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            box-shadow: 0 2px 8px #0006;
            transition: background 0.2s, color 0.2s;
        }
        .role-form button:hover {
            background: #fff200;
            color: #23272e;
        }
        .role-table input[type="checkbox"] {
            width: 22px;
            height: 22px;
            accent-color: #FFC300;
            cursor: pointer;
        }
        .back-link {
            display: inline-block;
            margin-top: 32px;
            color: #FFC300;
            font-weight: bold;
            text-decoration: none;
            font-size: 1.1em;
            transition: color 0.2s;
        }
        .back-link:hover {
            color: #fff200;
        }
    </style>
</head>
<body>
    <div class="role-container">
        <h2 class="role-header">Role Management</h2>

        <form class="role-form" action="update_role_permissions.php" method="post">
            <table class="role-table">
                <thead>
                    <tr>
                        <th>Role</th>
                        <th>Can Ban Users</th>
                        <th>Can Delete Rooms</th>
                        <th>Can Create Rooms</th>
                        <th>Can Mute Users</th>
                        <th>Can Change Roles</th>
                        <th>Username Color</th>
                        <th>Text Color</th>
                        <th>Avatar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($roles as $role): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($role['role']); ?></td>
                        <td><input type="checkbox" name="permissions[<?php echo $role['role']; ?>][can_ban_users]" value="1" <?php if ($role['can_ban_users']) echo 'checked'; ?>></td>
                        <td><input type="checkbox" name="permissions[<?php echo $role['role']; ?>][can_delete_rooms]" value="1" <?php if ($role['can_delete_rooms']) echo 'checked'; ?>></td>
                        <td><input type="checkbox" name="permissions[<?php echo $role['role']; ?>][can_create_rooms]" value="1" <?php if ($role['can_create_rooms']) echo 'checked'; ?>></td>
                        <td><input type="checkbox" name="permissions[<?php echo $role['role']; ?>][can_mute_users]" value="1" <?php if ($role['can_mute_users']) echo 'checked'; ?>></td>
                        <td><input type="checkbox" name="permissions[<?php echo $role['role']; ?>][can_change_roles]" value="1" <?php if ($role['can_change_roles']) echo 'checked'; ?>></td>
                        <td><input type="color" name="permissions[<?php echo $role['role']; ?>][username_color]" value="<?php echo htmlspecialchars($role['username_color'] ?? '#FFC300'); ?>"></td>
                        <td><input type="color" name="permissions[<?php echo $role['role']; ?>][text_color]" value="<?php echo htmlspecialchars($role['text_color'] ?? '#FFFFFF'); ?>"></td>
                        <td>
                            <input type="text" name="permissions[<?php echo $role['role']; ?>][avatar]" value="<?php echo htmlspecialchars($role['avatar'] ?? ''); ?>" placeholder="images/badges/admin.png" style="width:140px;">
                            <?php if (!empty($role['avatar'])): ?>
                                <img src="<?php echo htmlspecialchars($role['avatar']); ?>" alt="avatar" style="width:32px;height:32px;border-radius:50%;margin-left:6px;vertical-align:middle;">
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <button type="submit">Save Permissions</button>
        </form>

        <h3 style="margin-top:40px;color:#FFC300;">Add a Role</h3>
        <form class="role-form" action="add_role.php" method="post" style="margin-bottom:32px;">
            <input type="text" name="role_name" placeholder="Role name" required style="padding:8px;font-size:1.1em;">
            <label style="margin-left:18px;">Username Color: <input type="color" name="username_color" value="#FFC300"></label>
            <label style="margin-left:18px;">Text Color: <input type="color" name="text_color" value="#FFFFFF"></label>
            <label style="margin-left:18px;">Avatar: <input type="text" name="avatar" placeholder="images/badges/admin.png" style="width:140px;"></label>
            <button type="submit" style="margin-left:18px;">Add Role</button>
        </form>
        <a class="back-link" href="Admin.php">&larr; Back to Admin Panel</a>
    </div>
</body>
</html>
