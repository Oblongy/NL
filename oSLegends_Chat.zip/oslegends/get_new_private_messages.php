<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Not authenticated']);
    exit;
}

$user_id = $_SESSION['user_id'];
$mysqli = new mysqli('localhost', 'root', '', 'oschat');
if ($mysqli->connect_errno) {
    echo json_encode(['success' => false, 'error' => 'Database connection failed']);
    exit;
}

// Fetch unread messages
$stmt = $mysqli->prepare('SELECT pm.id, pm.sender_id, u.username AS sender_username, pm.message, pm.created_at FROM private_messages pm JOIN users u ON pm.sender_id = u.id WHERE pm.recipient_id = ? AND pm.is_read = 0 ORDER BY pm.created_at ASC');
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();
$messages = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

if (!empty($messages)) {
    // Mark messages as read
    $message_ids = array_map(function($msg) { return $msg['id']; }, $messages);
    $ids_placeholder = implode(',', array_fill(0, count($message_ids), '?'));
    $types = str_repeat('i', count($message_ids));

    $stmt_update = $mysqli->prepare("UPDATE private_messages SET is_read = 1 WHERE id IN ($ids_placeholder)");
    $stmt_update->bind_param($types, ...$message_ids);
    $stmt_update->execute();
    $stmt_update->close();
}

$mysqli->close();

echo json_encode(['success' => true, 'messages' => $messages]);
