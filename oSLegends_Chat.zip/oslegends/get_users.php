<?php
// get_users.php - Returns a JSON array of users active in the last 15 seconds
session_start();
header('Content-Type: application/json');

$mysqli = new mysqli('localhost', 'root', '', 'oschat');
if ($mysqli->connect_errno) {
    echo json_encode([]);
    exit;
}

$result = $mysqli->query(
    "SELECT u.id, u.username, u.role, rp.username_color, rp.text_color, rp.avatar FROM users u
     LEFT JOIN roles_permissions rp ON u.role = rp.role
     WHERE u.role != 'Banned'
       AND u.last_activity IS NOT NULL
       AND u.last_activity >= DATE_SUB(NOW(), INTERVAL 15 SECOND)"
);
if (!$result) {
    echo json_encode([]);
    $mysqli->close();
    exit;
}
$users = [];
while ($row = $result->fetch_assoc()) {
    $avatar = $row['avatar'];
    if (!$avatar) {
        if ($row['role'] === 'Super Administrator') {
            $avatar = 'images/badges/super_admin.png';
        } else {
            $avatar = 'images/badges/basic_user.png';
        }
    }
    $users[] = [
        'id' => $row['id'],
        'username' => $row['username'],
        'role' => $row['role'],
        'username_color' => $row['username_color'] ?? '#FFC300',
        'text_color' => $row['text_color'] ?? '#FFFFFF',
        'avatar' => $avatar
    ];
}
echo json_encode($users);
$mysqli->close();
