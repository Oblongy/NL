<?php
// create_room.php - Create a new chat room
header('Content-Type: application/json');
$mysqli = new mysqli('localhost', 'root', '', 'oschat');
if ($mysqli->connect_errno) {
    echo json_encode(['success' => false, 'error' => 'Database error.']);
    exit;
}
if (!isset($_POST['name']) || trim($_POST['name']) === '') {
    echo json_encode(['success' => false, 'error' => 'Room name required.']);
    exit;
}
$name = trim($_POST['name']);
$password = isset($_POST['password']) ? $_POST['password'] : null;
if ($password !== null && $password !== '') {
    $password_hash = password_hash($password, PASSWORD_DEFAULT);
} else {
    $password_hash = null;
}
$stmt = $mysqli->prepare('INSERT INTO rooms (name, password) VALUES (?, ?)');
$stmt->bind_param('ss', $name, $password_hash);
if ($stmt->execute()) {
    echo json_encode(['success' => true, 'id' => $stmt->insert_id, 'name' => $name]);
} else {
    echo json_encode(['success' => false, 'error' => 'Room creation failed.']);
}
$stmt->close();
$mysqli->close();
