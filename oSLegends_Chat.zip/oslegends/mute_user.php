<?php
// mute_user.php - Mute a user by username for 5 minutes (POST: username)
session_start();
header('Content-Type: application/json');

// Only allow specific roles to mute users
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || !in_array($_SESSION['role'], ['Administrator', 'Moderator', 'Super Moderator', 'Female Moderator'])) {
    echo json_encode(['success' => false, 'error' => 'Permission denied.']);
    exit;
}

if (!isset($_POST['username']) || trim($_POST['username']) === '') {
    echo json_encode(['success' => false, 'error' => 'No username provided.']);
    exit;
}

$username = trim($_POST['username']);

if ($username === $_SESSION['username']) {
    echo json_encode(['success' => false, 'error' => 'You cannot mute yourself.']);
    exit;
}
$mysqli = new mysqli('localhost', 'root', '', 'oschat');
if ($mysqli->connect_errno) {
    echo json_encode(['success' => false, 'error' => 'Database error.']);
    exit;
}

// Role hierarchy
$roles = [
    'Administrator' => 3,
    'Super Moderator' => 2,
    'Moderator' => 1,
    'Female Moderator' => 1,
    'Member' => 0,
    'basic user' => 0
];

$currentUserRole = $_SESSION['role'];

// Get target user's role
$stmt = $mysqli->prepare('SELECT id, role FROM users WHERE username = ?');
$stmt->bind_param('s', $username);
$stmt->execute();
$stmt->bind_result($user_id, $targetUserRole);

if ($stmt->fetch()) {
    $stmt->close();

    // Check if the current user can mute the target user
    if ($roles[$currentUserRole] <= $roles[$targetUserRole] && $currentUserRole !== 'Administrator') {
        echo json_encode(['success' => false, 'error' => 'You cannot mute a user with the same or higher role.']);
        exit;
    }

    // Insert mute record (create table if not exists)
    $mysqli->query('CREATE TABLE IF NOT EXISTS mutes (user_id INT PRIMARY KEY, muted_until DATETIME)');
    $muted_until = date('Y-m-d H:i:s', time() + 300); // 5 minutes from now
    $stmt2 = $mysqli->prepare('REPLACE INTO mutes (user_id, muted_until) VALUES (?, ?)');
    $stmt2->bind_param('is', $user_id, $muted_until);
    $stmt2->execute();
    $stmt2->close();
    // System message
    $botUsername = 'System';
    $botRole = 'System';
    $botMessage = $username . ' has been muted for 5 minutes.';
    $stmt3 = $mysqli->prepare('INSERT INTO messages (user_id, username, role, message) VALUES (?, ?, ?, ?)');
    $botUserId = 0;
    $stmt3->bind_param('isss', $botUserId, $botUsername, $botRole, $botMessage);
    $stmt3->execute();
    $stmt3->close();
    echo json_encode(['success' => true]);
} else {
    $stmt->close();
    echo json_encode(['success' => false, 'error' => 'User not found.']);
}
$mysqli->close();
