<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'], ['Super Administrator', 'Administrator', 'Super Moderator', 'Moderator', 'Female Moderator'])) {
    echo json_encode(['success' => false, 'error' => 'Permission denied.']);
    exit;
}

if (!isset($_GET['term']) || trim($_GET['term']) === '') {
    echo json_encode(['success' => false, 'error' => 'No search term provided.']);
    exit;
}

$term = '%' . trim($_GET['term']) . '%';
$mysqli = new mysqli('localhost', 'root', '', 'oschat');
if ($mysqli->connect_errno) {
    echo json_encode(['success' => false, 'error' => 'Database error.']);
    exit;
}

$stmt = $mysqli->prepare('SELECT id, username, email, role, ip_address FROM users WHERE username LIKE ?');
$stmt->bind_param('s', $term);
$stmt->execute();
$result = $stmt->get_result();
$users = [];
while ($row = $result->fetch_assoc()) {
    $users[] = $row;
}
$stmt->close();
$mysqli->close();

echo json_encode(['success' => true, 'users' => $users]);
