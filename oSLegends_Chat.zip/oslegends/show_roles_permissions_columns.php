<?php
$mysqli = new mysqli('localhost', 'root', '', 'oschat');
if ($mysqli->connect_errno) {
    die('Database connection failed.');
}
$result = $mysqli->query('DESCRIBE roles_permissions');
while ($row = $result->fetch_assoc()) {
    echo $row['Field'] . "\n";
}
$mysqli->close();
