<?php
// delete_room.php - Delete a chat room by ID (admin only)
session_start();
require_once 'session_check.php';
if (!isset($_SESSION['user_id']) || !isset($_SESSION['username'])) {
    header('Location: index.php');
    exit;
}
$mysqli = new mysqli('localhost', 'root', '', 'oschat');
if ($mysqli->connect_errno) {
    die('Database connection failed.');
}
$stmt = $mysqli->prepare('SELECT role FROM users WHERE id = ?');
$stmt->bind_param('i', $_SESSION['user_id']);
$stmt->execute();
$stmt->bind_result($role);
$stmt->fetch();
$stmt->close();
if (!in_array($role, ['Administrator', 'Super Moderator', 'Moderator', 'Female Moderator'])) {
    $mysqli->close();
    header('Location: chat.php');
    exit;
}
if (isset($_POST['room_id'])) {
    $room_id = intval($_POST['room_id']);
    $stmt = $mysqli->prepare('DELETE FROM rooms WHERE id = ?');
    $stmt->bind_param('i', $room_id);
    $stmt->execute();
    $stmt->close();
}
$mysqli->close();
header('Location: Admin.php');
exit;
