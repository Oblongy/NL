<?php
// delete_user.php - Delete a user (admin only)
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}
$mysqli = new mysqli('localhost', 'root', '', 'oschat');
if ($mysqli->connect_errno) {
    die('Database connection failed.');
}
// Check if current user is admin
$stmt = $mysqli->prepare('SELECT role FROM users WHERE id = ?');
$stmt->bind_param('i', $_SESSION['user_id']);
$stmt->execute();
$stmt->bind_result($role);
$stmt->fetch();
$stmt->close();
if ($role !== 'Administrator') {
    $mysqli->close();
    header('Location: index.php');
    exit;
}
// Delete user
if (isset($_POST['user_id'])) {
    $user_id = intval($_POST['user_id']);
    $stmt = $mysqli->prepare('DELETE FROM users WHERE id = ?');
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $stmt->close();
}
$mysqli->close();
header('Location: Admin.php');
exit;
