<?php
session_start();
header('Content-Type: application/json');
if (isset($_SESSION['user_id'])) {
    $mysqli = new mysqli('localhost', 'root', '', 'oschat');
    if ($mysqli->connect_errno) {
        echo json_encode(['username' => '', 'role' => '']);
        exit;
    }
    $stmt = $mysqli->prepare('SELECT username, role FROM users WHERE id = ?');
    $stmt->bind_param('i', $_SESSION['user_id']);
    $stmt->execute();
    $stmt->bind_result($username, $role);
    $stmt->fetch();
    $stmt->close();
    $mysqli->close();
    echo json_encode(['username' => $username, 'role' => $role]);
} else {
    echo json_encode(['username' => '', 'role' => '']);
}
