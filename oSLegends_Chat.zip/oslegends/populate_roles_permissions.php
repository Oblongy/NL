<?php
// Run this script once to populate the roles_permissions table with default roles and permissions
$mysqli = new mysqli('localhost', 'root', '', 'oschat');
if ($mysqli->connect_errno) {
    die('Database connection failed.');
}
$roles = [
    'Administrator' => [1, 1, 1, 1, 1],
    'Super Moderator' => [1, 1, 1, 1, 1],
    'Moderator' => [1, 0, 0, 1, 0],
    'Female Moderator' => [1, 0, 0, 1, 0],
    'Member' => [0, 0, 0, 0, 0],
    'basic user' => [0, 0, 0, 0, 0],
    'Banned' => [0, 0, 0, 0, 0]
];
foreach ($roles as $role => $perms) {
    $stmt = $mysqli->prepare('INSERT IGNORE INTO roles_permissions (role, can_ban_users, can_delete_rooms, can_create_rooms, can_mute_users, can_change_roles) VALUES (?, ?, ?, ?, ?, ?)');
    $stmt->bind_param('siiiii', $role, $perms[0], $perms[1], $perms[2], $perms[3], $perms[4]);
    $stmt->execute();
    $stmt->close();
}
$mysqli->close();
echo "Roles and permissions populated.";
