<?php
// get_rooms.php - Returns a JSON array of all chat rooms
header('Content-Type: application/json');
$mysqli = new mysqli('localhost', 'root', '', 'oschat');
if ($mysqli->connect_errno) {
    echo json_encode([]);
    exit;
}
$result = $mysqli->query("SELECT id, name, password FROM rooms ORDER BY name ASC");
$rooms = [];
while ($row = $result->fetch_assoc()) {
    $rooms[] = [
        'id' => $row['id'],
        'name' => $row['name'],
        'has_password' => !empty($row['password'])
    ];
}
$mysqli->close();
echo json_encode($rooms);
