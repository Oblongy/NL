<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id']) || !isset($_SESSION['session_id'])) {
    header('Location: index.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$current_session_id = $_SESSION['session_id'];

$mysqli = new mysqli('localhost', 'root', '', 'oschat');
if ($mysqli->connect_errno) {
    return;
}

$stmt = $mysqli->prepare('SELECT session_id FROM users WHERE id = ?');
$stmt->bind_param('i', $user_id);
$stmt->execute();
$stmt->bind_result($db_session_id);
$stmt->fetch();
$stmt->close();
$mysqli->close();

if ($db_session_id !== $current_session_id) {
    $_SESSION = array();
    session_destroy();
    header('Location: index.php?kicked=1');
    exit;
}
?>